package com.nexan.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Set;

/**
 * Hosts the Nexan web UI (assets/www) in a WebView and bridges native speech
 * recognition and text-to-speech to it. Assets are served from a private https
 * origin so ES modules, localStorage and fetch behave like a normal web app.
 */
public class MainActivity extends Activity {

    private static final String HOST = "app.nexan.local";
    private static final int REQ_MIC = 7;

    private WebView web;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String pendingLang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF04060C);
        getWindow().setNavigationBarColor(0xFF04060C);

        tts = new TextToSpeech(this, status -> ttsReady = status == TextToSpeech.SUCCESS);
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { emit("tts-start", ""); }
            @Override public void onRangeStart(String id, int start, int end, int frame) { emit("tts-range", ""); }
            @Override public void onDone(String id) { emit("tts-done", ""); }
            @Override public void onStop(String id, boolean interrupted) { emit("tts-done", ""); }
            @Override public void onError(String id) { emit("tts-done", ""); }
        });

        web = new WebView(this);
        web.setBackgroundColor(0xFF04060C);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        web.addJavascriptInterface(new Bridge(), "NexanNative");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (!HOST.equals(u.getHost())) return null;
                String p = u.getPath();
                if (p == null || p.equals("/")) p = "/index.html";
                if (p.contains("..")) return notFound();
                try {
                    InputStream in = getAssets().open("www" + p);
                    return new WebResourceResponse(mime(p), "UTF-8", in);
                } catch (IOException e) {
                    return notFound();
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                if (HOST.equals(r.getUrl().getHost())) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, r.getUrl())); } catch (Exception ignored) { }
                return true;
            }
        });
        setContentView(web);
        web.loadUrl("https://" + HOST + "/index.html");
    }

    private WebResourceResponse notFound() {
        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private String mime(String p) {
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js") || p.endsWith(".mjs")) return "text/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".json") || p.endsWith(".webmanifest")) return "application/json";
        return "application/octet-stream";
    }

    /** Sends an event to the web UI (window.__nx). Safe from any thread. */
    private void emit(final String type, final String data) {
        runOnUiThread(() -> {
            if (web != null) {
                web.evaluateJavascript("window.__nx&&window.__nx(" + JSONObject.quote(type) + "," + JSONObject.quote(data) + ")", null);
            }
        });
    }

    // ---------- Speech recognition ----------

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle params) { emit("ready", ""); }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float rmsdB) { emit("rms", String.valueOf(rmsdB)); }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { }
        @Override public void onEvent(int eventType, Bundle params) { }

        @Override
        public void onPartialResults(Bundle b) {
            String t = first(b);
            if (!t.isEmpty()) emit("partial", t);
        }

        @Override
        public void onResults(Bundle b) { emit("result", first(b)); }

        @Override
        public void onError(int error) {
            String code;
            switch (error) {
                case SpeechRecognizer.ERROR_NO_MATCH:
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: code = "no-speech"; break;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: code = "not-allowed"; break;
                case SpeechRecognizer.ERROR_NETWORK:
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: code = "network"; break;
                case SpeechRecognizer.ERROR_AUDIO: code = "audio-capture"; break;
                case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: code = "busy"; break;
                default: code = "error";
            }
            emit("error", code);
        }
    };

    private String first(Bundle b) {
        ArrayList<String> r = b == null ? null : b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (r == null || r.isEmpty() || r.get(0) == null) ? "" : r.get(0).trim();
    }

    private void startListening(String lang) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            emit("error", "unsupported");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(listener);
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        recognizer.cancel();
        recognizer.startListening(i);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_MIC) return;
        if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && pendingLang != null) {
            startListening(pendingLang);
        } else {
            emit("error", "not-allowed");
        }
        pendingLang = null;
    }

    // ---------- Text to speech ----------

    private void speakNow(String text, String lang, float pitch, float rate, boolean female) {
        if (!ttsReady) { emit("tts-error", "not-ready"); return; }
        Locale loc = Locale.forLanguageTag(lang);
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            emit("tts-error", "no-voice");
            return;
        }
        try {
            Set<Voice> all = tts.getVoices();
            Voice pick = null;
            if (all != null) {
                for (Voice v : all) {
                    if (!v.getLocale().getLanguage().equals(loc.getLanguage()) || v.isNetworkConnectionRequired()) continue;
                    String n = v.getName().toLowerCase(Locale.ROOT);
                    boolean isF = n.contains("female");
                    boolean isM = n.contains("male") && !isF;
                    if ((female && isF) || (!female && isM)) { pick = v; break; }
                }
            }
            if (pick != null) tts.setVoice(pick);
        } catch (Exception ignored) { }
        tts.setPitch(pitch);
        tts.setSpeechRate(rate);
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nx" + System.nanoTime());
    }

    // ---------- JavaScript bridge ----------

    private class Bridge {
        @JavascriptInterface
        public String available() {
            return "{\"stt\":" + SpeechRecognizer.isRecognitionAvailable(MainActivity.this) + ",\"tts\":true}";
        }

        @JavascriptInterface
        public void listen(final String lang) {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    pendingLang = lang;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                } else {
                    startListening(lang);
                }
            });
        }

        @JavascriptInterface
        public void stopListen() {
            runOnUiThread(() -> { if (recognizer != null) recognizer.stopListening(); });
        }

        @JavascriptInterface
        public void speak(final String text, final String lang, final double pitch, final double rate, final boolean female) {
            runOnUiThread(() -> speakNow(text, lang, (float) pitch, (float) rate, female));
        }

        @JavascriptInterface
        public void stopSpeak() {
            runOnUiThread(() -> { if (tts != null) tts.stop(); });
        }
    }

    // ---------- Lifecycle ----------

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.nexanBack?window.nexanBack():false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (recognizer != null) recognizer.cancel();
        if (tts != null) tts.stop();
        web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        web.destroy();
    }
}
