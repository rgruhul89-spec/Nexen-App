import { store } from '../state.js';
import { toast } from './toast.js';

const field = (label, control) => { const l = document.createElement('label'); l.append(Object.assign(document.createElement('span'), { textContent: label }), control); return l; };
const button = (text, cls, fn) => Object.assign(document.createElement('button'), { type: 'button', textContent: text, className: cls, onclick: fn });
const input = (type, value, ph) => Object.assign(document.createElement('input'), { type, value, placeholder: ph, autocomplete: 'off', spellcheck: false });

/** Add a new entry here to extend Settings. Each section renders its own detail view. */
const SECTIONS = [
  {
    id: 'profile', title: 'Profile', summary: () => store.get().name || 'Name not set',
    render(body) {
      const s = store.get();
      const name = input('text', s.name, 'Your name');
      const lang = document.createElement('select');
      [['bn-BD', 'Bangla'], ['en-US', 'English']].forEach(([v, t]) => lang.add(new Option(t, v, false, v === s.lang)));
      body.append(field('Name', name), field('Voice language', lang),
        button('Save profile', 'primary', () => { store.set({ name: name.value.trim(), lang: lang.value }); toast('Profile saved'); open(null); }));
    },
  },
  {
    id: 'api', title: 'API keys', summary: () => (store.get().gemini ? 'Configured' : 'Not configured'),
    render(body) {
      const key = input('password', store.get().gemini, 'Paste Gemini API key');
      const state = document.createElement('p');
      const paint = () => {
        const k = store.get().gemini;
        state.className = `chip ${k ? 'ok' : 'warn'}`;
        state.textContent = k ? `Configured, ends in ${k.slice(-4)}` : 'Missing. Chat and voice are disabled.';
      };
      const note = Object.assign(document.createElement('p'), { className: 'note', textContent: 'The key is stored only in this browser on this device. It is never part of the app code.' });
      body.append(state, field('Gemini API key', key),
        button('Show or hide key', 'ghost', () => { key.type = key.type === 'password' ? 'text' : 'password'; }),
        button('Save key', 'primary', () => {
          const v = key.value.trim();
          if (!v) return toast('Enter a key first, or use Remove key.');
          store.set({ gemini: v }); paint(); toast('API key saved');
        }),
        button('Remove key', 'ghost', () => { store.set({ gemini: '' }); key.value = ''; paint(); toast('API key removed'); }), note);
      paint();
    },
  },
];

let open;
export function initSettings() {
  const body = document.getElementById('setBody');
  const title = document.getElementById('setTitle');
  let section = null;

  open = (id) => {
    section = SECTIONS.find((x) => x.id === id) || null;
    body.innerHTML = ''; body.scrollTop = 0;
    body.className = 'swap';
    title.textContent = section ? section.title : 'Settings';
    if (section) return section.render(body);
    SECTIONS.forEach((x) => {
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'row';
      b.innerHTML = `<span><b>${x.title}</b><small></small></span><svg viewBox="0 0 24 24" width="18" height="18"><path d="M9 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
      b.querySelector('small').textContent = x.summary();
      b.onclick = () => open(x.id);
      body.appendChild(b);
    });
    body.appendChild(button('Exit settings', 'ghost exit', () => store.set({ view: 'home' })));
  };
  document.getElementById('setBack').onclick = () => (section ? open(null) : store.set({ view: 'home' }));
  store.on((_, p) => { if (p.view === 'settings') open(null); });
  open(null);
}
