import { store } from '../state.js';
import { ASSISTANTS, avatar } from '../assistants.js';
import { sendText, switchAssistant } from '../controller.js';

export function initChat() {
  const list = document.getElementById('msgs');
  const form = document.getElementById('chatForm');
  const input = document.getElementById('chatIn');
  const sw = document.getElementById('chatSwitch');

  const renderSwitch = () => {
    const cur = store.get().assistant;
    sw.innerHTML = '';
    Object.values(ASSISTANTS).forEach((a) => {
      const b = document.createElement('button');
      b.type = 'button'; b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', String(a.id === cur));
      b.className = a.id === cur ? 'on' : '';
      b.style.setProperty('--a1', a.c1);
      b.innerHTML = `<span class="mini">${avatar(a.id)}</span>${a.name}`;
      b.onclick = () => switchAssistant(a.id);
      sw.appendChild(b);
    });
  };

  const renderMsgs = () => {
    const { messages, phase, assistant, name } = store.get();
    list.innerHTML = '';
    if (!messages.length) {
      const e = document.createElement('p');
      e.className = 'empty';
      e.textContent = `Ask ${ASSISTANTS[assistant].name} anything. Switch assistants above at any time.`;
      list.appendChild(e);
    }
    messages.forEach((m) => {
      const d = document.createElement('div');
      const a = ASSISTANTS[m.a];
      d.className = `m ${m.role === 'user' ? 'user' : 'bot'}`;
      if (m.role !== 'user') d.style.setProperty('--a1', a.c1);
      const who = document.createElement('small');
      who.textContent = m.role === 'user' ? name || 'You' : a.name;
      const t = document.createElement('p');
      t.textContent = m.text;
      d.append(who, t);
      list.appendChild(d);
    });
    if (phase === 'processing') {
      const d = document.createElement('div');
      d.className = 'm bot typing'; d.setAttribute('aria-label', 'Thinking');
      d.style.setProperty('--a1', ASSISTANTS[assistant].c1);
      d.innerHTML = '<i></i><i></i><i></i>';
      list.appendChild(d);
    }
    list.scrollTop = list.scrollHeight;
    form.querySelector('button').disabled = phase !== 'idle';
  };

  form.onsubmit = (e) => {
    e.preventDefault();
    const v = input.value;
    if (!v.trim() || store.get().phase !== 'idle') return;
    input.value = '';
    sendText(v);
  };
  store.on((_, p) => {
    if ('assistant' in p) renderSwitch();
    if ('messages' in p || 'phase' in p || 'assistant' in p || 'name' in p) renderMsgs();
  });
  renderSwitch(); renderMsgs();
}
