import { store } from '../state.js';
import { ASSISTANTS, avatar, brandMark } from '../assistants.js';
import { switchAssistant } from '../controller.js';

export function initHeader() {
  document.getElementById('brandMark').innerHTML = brandMark();
  const btn = document.getElementById('selBtn');
  const menu = document.getElementById('selMenu');
  const close = () => { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); };

  const render = () => {
    const cur = store.get().assistant;
    document.getElementById('selAv').innerHTML = avatar(cur);
    document.getElementById('selName').textContent = ASSISTANTS[cur].name;
    menu.innerHTML = '';
    Object.values(ASSISTANTS).forEach((a) => {
      const li = document.createElement('li');
      li.innerHTML = `<button type="button" role="menuitemradio" aria-checked="${a.id === cur}" class="${a.id === cur ? 'on' : ''}" style="--a1:${a.c1};--a2:${a.c2}">
        <span class="mini">${avatar(a.id)}</span><span class="who"><b>${a.name}</b><small>${a.role}</small></span>
        <svg class="tick" viewBox="0 0 24 24" width="18" height="18"><path d="M5 12l5 5 9-10" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg></button>`;
      li.firstElementChild.onclick = () => { switchAssistant(a.id); close(); };
      menu.appendChild(li);
    });
  };

  btn.onclick = (e) => {
    e.stopPropagation();
    const open = menu.hidden;
    menu.hidden = !open;
    btn.setAttribute('aria-expanded', String(open));
  };
  document.addEventListener('click', (e) => { if (!menu.contains(e.target)) close(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); });
  store.on((_, p) => { if ('assistant' in p) render(); });
  render();
}
