import { store, signal } from '../state.js';
import { ASSISTANTS, avatar } from '../assistants.js';
import { toggleVoice } from '../controller.js';

const LABEL = { idle: 'Tap to talk', listening: 'Listening', processing: 'Thinking', speaking: 'Speaking' };
const SPEED = { idle: 0.12, listening: 0.3, processing: 1.5, speaking: 0.55 };
const LOW_END = (navigator.hardwareConcurrency || 4) <= 4;
const FRAME_MS = LOW_END ? 33 : 16;

export function initStage() {
  const cv = document.getElementById('cv');
  const ctx = cv.getContext('2d');
  const orb = document.getElementById('orb');
  const app = document.getElementById('app');
  const reduce = matchMedia('(prefers-reduced-motion: reduce)');
  const dots = Array.from({ length: LOW_END ? 14 : 26 }, (_, i) => ({ a: Math.random() * 6.28, r: 1.05 + Math.random() * 0.4, s: 0.2 + Math.random() * 0.5, z: 1 + Math.random() * 1.6, i }));
  let size = 0, rot = 0, last = 0, lvl = 0, raf = 0;

  const theme = () => {
    const a = ASSISTANTS[store.get().assistant];
    const r = document.documentElement.style;
    r.setProperty('--a1', a.c1); r.setProperty('--a2', a.c2); r.setProperty('--rgb', a.rgb);
    document.getElementById('orbAv').innerHTML = avatar(a.id);
    document.getElementById('orbName').textContent = a.name;
    orb.classList.remove('swap'); void orb.offsetWidth; orb.classList.add('swap');
  };
  const status = () => {
    const { phase, partial } = store.get();
    app.dataset.phase = phase;
    document.getElementById('status').textContent = LABEL[phase];
    document.getElementById('partial').textContent = partial;
  };
  const fit = () => {
    const dpr = Math.min(devicePixelRatio || 1, 2);
    size = cv.clientWidth;
    cv.width = cv.height = Math.round(size * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  };

  function draw(t) {
    raf = requestAnimationFrame(draw);
    if (t - last < FRAME_MS || size === 0) return;
    const dt = Math.min((t - last) / 1000, 0.1); last = t;
    const { phase, assistant } = store.get();
    const a = ASSISTANTS[assistant];
    lvl += (signal.level - lvl) * 0.35;
    signal.level *= 0.9;
    const still = reduce.matches;
    rot += still ? 0 : dt * SPEED[phase];
    const c = size / 2, R = size * 0.347;
    orb.style.setProperty('--lvl', lvl.toFixed(2));
    ctx.clearRect(0, 0, size, size);
    ctx.lineCap = 'round';
    const rings = [[1.1, 2, a.c1, 1], [1.23, 1.5, a.c2, -1.4], [1.37, 1, a.c1, 0.7]];
    rings.forEach(([k, w, col, dir], i) => {
      const breathe = phase === 'idle' ? Math.sin(t / 1400 + i) * 0.006 : lvl * 0.05 * (i + 1);
      const rad = R * (k + breathe);
      const len = phase === 'processing' ? 0.55 : 1.5 + lvl;
      ctx.strokeStyle = col; ctx.lineWidth = w;
      ctx.globalAlpha = 0.25 + 0.2 * i * 0 + (phase === 'idle' ? 0 : 0.3 + lvl * 0.3);
      for (let s = 0; s < 3; s++) {
        const st = rot * dir * 2 + (s * 6.283) / 3;
        ctx.beginPath(); ctx.arc(c, c, rad, st, st + len); ctx.stroke();
      }
    });
    ctx.fillStyle = a.c2;
    dots.forEach((d) => {
      d.a += still ? 0 : dt * d.s * (0.4 + SPEED[phase]) * (d.i % 2 ? 1 : -1);
      const rr = R * (d.r + lvl * 0.08);
      ctx.globalAlpha = 0.35 + 0.35 * Math.sin(t / 700 + d.i);
      ctx.beginPath(); ctx.arc(c + Math.cos(d.a) * rr, c + Math.sin(d.a) * rr, d.z, 0, 6.283); ctx.fill();
    });
    ctx.globalAlpha = 1;
  }

  const run = () => { cancelAnimationFrame(raf); if (!document.hidden && store.get().view === 'home') raf = requestAnimationFrame(draw); };
  orb.onclick = toggleVoice;
  new ResizeObserver(fit).observe(cv);
  document.addEventListener('visibilitychange', run);
  store.on((_, p) => {
    if ('assistant' in p) theme();
    if ('phase' in p || 'partial' in p) status();
    if ('view' in p) run();
  });
  theme(); status(); fit(); run();
}
