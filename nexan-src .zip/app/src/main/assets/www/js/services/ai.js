import { systemPrompt } from '../assistants.js';

const MODEL = 'gemini-flash-latest';
const fail = (code, message) => Object.assign(new Error(message), { code });

/** Sends the conversation to Gemini. The key comes from on-device settings, never from source code. */
export async function ask(messages, assistant, key) {
  if (!key) throw fail('no-key', 'Add your Gemini API key in Settings to start.');
  const contents = messages.slice(-14).map((m) => ({ role: m.role === 'user' ? 'user' : 'model', parts: [{ text: m.text }] }));
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 25000);
  try {
    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
      method: 'POST', signal: ctl.signal,
      headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemPrompt(assistant) }] },
        contents, generationConfig: { temperature: 0.7, maxOutputTokens: 600 },
      }),
    });
    if (res.status === 400 || res.status === 403) throw fail('bad-key', 'The API key was rejected. Check it in Settings.');
    if (res.status === 429) throw fail('rate', 'Rate limit reached. Try again in a moment.');
    if (!res.ok) throw fail('http', `The AI service returned an error (${res.status}).`);
    const data = await res.json();
    const text = (data.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('').trim();
    if (!text) throw fail('empty', 'No answer came back. Try rephrasing.');
    return text;
  } catch (e) {
    if (e.code) throw e;
    if (e.name === 'AbortError') throw fail('timeout', 'The request timed out. Check your connection.');
    throw fail('network', 'Could not reach the AI service. Check your connection.');
  } finally { clearTimeout(timer); }
}
