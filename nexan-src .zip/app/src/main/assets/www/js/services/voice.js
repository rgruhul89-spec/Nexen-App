import { signal } from '../state.js';

const NX = window.NexanNative || null;
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
export const caps = NX
  ? (() => { try { return JSON.parse(NX.available()); } catch { return { stt: false, tts: false }; } })()
  : { stt: !!SR, tts: 'speechSynthesis' in window };
const fail = (code) => Object.assign(new Error(code), { code });

/* ---------- Native bridge (Android app): events arrive through window.__nx ---------- */
let job = null;      // { resolve, reject, onPartial, text }
let talk = null;     // resolve function of the current speak()
const settle = (fn) => { const j = job; job = null; if (j) fn(j); };

window.__nx = (type, data) => {
  switch (type) {
    case 'rms': signal.level = Math.max(signal.level, Math.min(1, (parseFloat(data) + 2) / 11)); break;
    case 'partial': if (job) { job.text = data; job.onPartial(data); } break;
    case 'result': settle((j) => j.resolve((data || j.text).trim())); break;
    case 'error': settle((j) => j.reject(fail(data))); break;
    case 'tts-start': signal.level = 0.8; break;
    case 'tts-range': signal.level = 0.7 + Math.random() * 0.3; break;
    case 'tts-done': if (talk) { const t = talk; talk = null; t(true); } break;
    case 'tts-error': if (talk) { const t = talk; talk = null; t(false); } break;
    default: break;
  }
};

/* ---------- Browser fallback ---------- */
let rec = null;
function listenWeb(lang, onPartial) {
  return new Promise((resolve, reject) => {
    if (!SR) return reject(fail('unsupported'));
    const r = (rec = new SR());
    let text = '';
    r.lang = lang; r.interimResults = true; r.maxAlternatives = 1;
    r.onspeechstart = () => { signal.level = 0.6; };
    r.onresult = (e) => {
      text = Array.from(e.results).map((x) => x[0].transcript).join(' ');
      signal.level = 0.5 + Math.random() * 0.5;
      onPartial(text);
    };
    r.onerror = (e) => reject(fail(e.error));
    r.onend = () => resolve(text.trim());
    try { r.start(); } catch { reject(fail('busy')); }
  });
}

function pickVoice(a, lang) {
  const pool = speechSynthesis.getVoices().filter((v) => v.lang.toLowerCase().startsWith(lang.slice(0, 2)));
  return pool.find((v) => a.voiceHint.test(v.name) && !a.voiceNot.test(v.name)) || pool[0] || null;
}
function speakWeb(text, assistant, lang) {
  return new Promise((resolve) => {
    const synth = speechSynthesis;
    synth.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = lang;
    const v = pickVoice(assistant, lang);
    if (v) u.voice = v;
    u.pitch = assistant.pitch; u.rate = assistant.rate;
    u.onstart = () => { signal.level = 0.8; };
    u.onboundary = () => { signal.level = 0.7 + Math.random() * 0.3; };
    u.onend = () => resolve(true);
    u.onerror = () => resolve(false);
    synth.speak(u);
  });
}

/* ---------- Public API ---------- */
/** Listens once. Level follows real microphone volume (app) or recognizer events (browser). */
export function listen(lang, onPartial) {
  if (!NX) return listenWeb(lang, onPartial);
  return new Promise((resolve, reject) => {
    job = { resolve, reject, onPartial, text: '' };
    NX.listen(lang);
  });
}
export function stopListening() {
  if (NX) NX.stopListen();
  else { try { rec?.stop(); } catch { /* already stopped */ } }
}

/** Speaks text. Word boundaries from the synthesizer drive the speaking animation. */
export function speak(text, assistant) {
  if (!caps.tts) return Promise.resolve(false);
  const lang = /[\u0980-\u09FF]/.test(text) ? 'bn-BD' : 'en-US';
  if (!NX) return speakWeb(text, assistant, lang);
  return new Promise((resolve) => {
    talk = resolve;
    NX.speak(text, lang, assistant.pitch, assistant.rate, assistant.id === 'nefi');
  });
}
export function stopSpeaking() {
  if (NX) { NX.stopSpeak(); if (talk) { const t = talk; talk = null; t(true); } }
  else if (caps.tts) speechSynthesis.cancel();
}
