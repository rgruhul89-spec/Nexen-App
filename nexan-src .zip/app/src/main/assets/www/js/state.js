const KEY = 'nexan.v1';
const PERSIST = ['assistant', 'name', 'lang', 'gemini'];
const defaults = { assistant: 'nexan', name: '', lang: 'bn-BD', gemini: '' };

function load() {
  try { return { ...defaults, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; }
  catch { return { ...defaults }; }
}

/** Mutable per-frame audio activity (0..1). Written by services, read by the stage; no events. */
export const signal = { level: 0 };

const subs = new Set();
const s = { ...load(), phase: 'idle', view: 'home', messages: [], partial: '' };

export const store = {
  get: () => s,
  set(patch) {
    Object.assign(s, patch);
    if (PERSIST.some((k) => k in patch)) {
      try { localStorage.setItem(KEY, JSON.stringify(Object.fromEntries(PERSIST.map((k) => [k, s[k]])))); }
      catch { /* storage unavailable: keep in memory */ }
    }
    subs.forEach((f) => f(s, patch));
  },
  on(f) { subs.add(f); },
};
