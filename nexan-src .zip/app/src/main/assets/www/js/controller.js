import { store } from './state.js';
import { ASSISTANTS } from './assistants.js';
import { ask } from './services/ai.js';
import * as voice from './services/voice.js';
import { toast } from './ui/toast.js';

const VOICE_ERRORS = {
  'not-allowed': 'Microphone access is blocked. Allow it in the browser site settings.',
  'service-not-allowed': 'Speech recognition is blocked on this device.',
  'no-speech': 'No speech detected. Tap the voice button and try again.',
  'audio-capture': 'No microphone was found.',
  network: 'Speech recognition needs an internet connection.',
  unsupported: 'Speech recognition is not available. Install or enable the Google app and its voice services.',
  busy: 'The microphone is busy. Try again in a moment.',
  aborted: 'Listening was interrupted.',
};
const current = () => ASSISTANTS[store.get().assistant];
const push = (role, text) => store.set({ messages: [...store.get().messages, { role, text, a: store.get().assistant }] });

/** Shared by text and voice: adds the user turn, asks the AI, adds the reply. Returns the reply or null. */
async function converse(text) {
  push('user', text);
  store.set({ phase: 'processing' });
  try {
    const reply = await ask(store.get().messages, current(), store.get().gemini);
    push('model', reply);
    return reply;
  } catch (e) {
    toast(e.message);
    return null;
  }
}

export async function sendText(text) {
  if (!text.trim() || store.get().phase !== 'idle') return;
  await converse(text.trim());
  store.set({ phase: 'idle' });
}

export function switchAssistant(id) {
  if (id === store.get().assistant) return;
  voice.stopSpeaking(); voice.stopListening();
  store.set({ assistant: id, phase: 'idle', partial: '' });
}

export async function toggleVoice() {
  const { phase, lang } = store.get();
  if (phase === 'listening') return voice.stopListening();
  if (phase === 'speaking') { voice.stopSpeaking(); return; }
  if (phase !== 'idle') return;
  if (!voice.caps.stt) return toast(VOICE_ERRORS.unsupported);
  if (!store.get().gemini) return toast('Add your Gemini API key in Settings to use voice.');
  store.set({ phase: 'listening', partial: '' });
  let heard = '';
  try {
    heard = await voice.listen(lang, (t) => store.set({ partial: t }));
  } catch (e) {
    store.set({ phase: 'idle', partial: '' });
    return toast(VOICE_ERRORS[e.code] || 'Voice input failed. Try again.');
  }
  store.set({ partial: '' });
  if (!heard) { store.set({ phase: 'idle' }); return toast(VOICE_ERRORS['no-speech']); }
  const reply = await converse(heard);
  if (reply === null) return store.set({ phase: 'idle' });
  if (!voice.caps.tts) toast('Text-to-speech is not available. The reply is in the chat.');
  store.set({ phase: 'speaking' });
  await voice.speak(reply, current());
  store.set({ phase: 'idle' });
}
