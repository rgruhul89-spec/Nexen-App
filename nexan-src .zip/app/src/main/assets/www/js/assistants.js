export const ASSISTANTS = {
  nexan: { id: 'nexan', name: 'Nexan', role: 'Male voice', c1: '#3d7bff', c2: '#38e1ff', rgb: '61,123,255', pitch: 0.82, rate: 1,
    voiceHint: /male|david|mark|daniel|james|guy|george/i, voiceNot: /female/i,
    persona: 'You are Nexan, a calm, precise and confident male AI assistant.' },
  nefi: { id: 'nefi', name: 'Nefi', role: 'Female voice', c1: '#ff5cae', c2: '#a78bff', rgb: '255,92,174', pitch: 1.2, rate: 1.03,
    voiceHint: /female|zira|samantha|susan|hazel|karen|aria|jenny/i, voiceNot: /\bmale\b/i,
    persona: 'You are Nefi, a warm, bright and expressive female AI assistant.' },
};

export const systemPrompt = (a) =>
  `${a.persona} Reply in the language the user wrote in (Bengali in Bengali script, or English). ` +
  'Keep answers short and natural because they may be spoken aloud. Do not use emojis, markdown or lists. ' +
  'You cannot control the phone; if asked to, say so honestly.';

const N = 'M34 67V33l32 34V33';

export function brandMark() {
  return `<svg viewBox="0 0 100 100" class="mark" aria-hidden="true">
    <circle class="m-ring" cx="50" cy="50" r="44" fill="none" stroke="#3d7bff" stroke-width="3" stroke-dasharray="90 186" stroke-linecap="round"/>
    <circle class="m-ring r2" cx="50" cy="50" r="36" fill="none" stroke="#38e1ff" stroke-width="2" stroke-dasharray="40 186" stroke-linecap="round" opacity=".8"/>
    <path class="m-n" d="${N}" fill="none" stroke="#e9eefc" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" pathLength="100"/></svg>`;
}

export function avatar(id) {
  const a = ASSISTANTS[id];
  if (id === 'nexan') {
    return `<svg viewBox="0 0 100 100" class="av" aria-hidden="true"><g class="spin"><path d="M50 8l36 21v42L50 92 14 71V29z" fill="none" stroke="${a.c1}" stroke-width="3" stroke-linejoin="round" stroke-dasharray="150 60"/></g>
      <path d="${N}" fill="none" stroke="${a.c2}" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }
  return `<svg viewBox="0 0 100 100" class="av" aria-hidden="true"><g class="spin slow">
      <ellipse cx="50" cy="50" rx="40" ry="15" fill="none" stroke="${a.c1}" stroke-width="3"/>
      <ellipse cx="50" cy="50" rx="40" ry="15" fill="none" stroke="${a.c2}" stroke-width="3" transform="rotate(60 50 50)"/>
      <ellipse cx="50" cy="50" rx="40" ry="15" fill="none" stroke="${a.c1}" stroke-width="3" transform="rotate(120 50 50)" opacity=".7"/></g>
    <circle cx="50" cy="50" r="9" fill="${a.c2}"/></svg>`;
}
