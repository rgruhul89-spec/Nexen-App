import { store } from './state.js';
import { brandMark } from './assistants.js';
import { initHeader } from './ui/header.js';
import { initStage } from './ui/stage.js';
import { initChat } from './ui/chat.js';
import { initSettings } from './ui/settings.js';
import { toggleVoice } from './controller.js';
import { toast } from './ui/toast.js';

const app = document.getElementById('app');
const nav = document.getElementById('nav');

function setView(v) {
  store.set({ view: v });
}
store.on((s, p) => {
  if (!('view' in p)) return;
  app.dataset.view = s.view;
  nav.querySelectorAll('[data-go]').forEach((b) => {
    const on = b.dataset.go === s.view || (b.dataset.go === 'voice' && s.view === 'home');
    b.classList.toggle('on', on);
    on ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current');
  });
});

nav.addEventListener('click', (e) => {
  const b = e.target.closest('[data-go]');
  if (!b) return;
  const go = b.dataset.go;
  if (go === 'voice') {
    const wasHome = store.get().view === 'home';
    setView('home');
    if (wasHome || store.get().phase === 'idle') toggleVoice();
  } else setView(go);
});

document.getElementById('splashMark').innerHTML = brandMark();
initHeader(); initStage(); initChat(); initSettings();
setView('home');

const splash = document.getElementById('splash');
const endSplash = () => { splash.classList.add('out'); setTimeout(() => splash.remove(), 600); };
setTimeout(endSplash, matchMedia('(prefers-reduced-motion: reduce)').matches ? 600 : 2300);
splash.onclick = endSplash;

if (!store.get().gemini) setTimeout(() => toast('Open Settings to add your Gemini API key.'), 3000);
/** Called by the Android back button. Returns true when the UI handled it. */
window.nexanBack = () => {
  const menu = document.getElementById('selMenu');
  if (!menu.hidden) { menu.hidden = true; return true; }
  if (store.get().view !== 'home') { setView('home'); return true; }
  return false;
};
