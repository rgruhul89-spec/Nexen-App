package com.nexan.assistant;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Speaks with a cute anime-girl style voice.
 * First choice: Gemini text-to-speech (needs internet + the same Gemini key).
 * Fallback: the phone's own text-to-speech with a raised pitch.
 */
final class Voice {

    private static final String[] TTS_MODELS = {"gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts"};
    static final String[] VOICES = {"Leda", "Zephyr", "Aoede", "Callirrhoe", "Kore", "Puck"};
    private static final Pattern BENGALI = Pattern.compile("[\\u0980-\\u09FF]");
    private static final int RATE = 24000;

    private final Context ctx;
    private final SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private volatile AudioTrack track;
    private volatile int token = 0;
    private volatile Runnable pendingDone;

    Voice(Context c) {
        ctx = c.getApplicationContext();
        prefs = ctx.getSharedPreferences("nexan", Context.MODE_PRIVATE);
        tts = new TextToSpeech(ctx, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                ttsReady = true;
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { }
                    @Override public void onDone(String utteranceId) { finishLocal(); }
                    @Override public void onError(String utteranceId) { finishLocal(); }
                });
            }
        });
    }

    private void finishLocal() {
        Runnable d = pendingDone;
        pendingDone = null;
        if (d != null) ui.post(d);
    }

    /** Speaks text. done (may be null) runs on the main thread when finished. It is NOT run if stop() cancels the speech. */
    void speak(final String text, final Runnable done) {
        token++;
        final int my = token;
        halt();
        new Thread(() -> {
            boolean played = false;
            try {
                byte[] pcm = geminiTts(text);
                if (pcm != null && my == token) {
                    play(pcm, my);
                    played = true;
                }
            } catch (Exception ignored) { }
            if (my != token) return;
            if (played) {
                if (done != null) ui.post(done);
            } else {
                ui.post(() -> speakLocal(text, my, done));
            }
        }).start();
    }

    void stop() {
        token++;
        halt();
    }

    void shutdown() {
        token++;
        halt();
        if (tts != null) {
            tts.shutdown();
            tts = null;
        }
    }

    private void halt() {
        pendingDone = null;
        AudioTrack t = track;
        if (t != null) {
            try { t.stop(); } catch (Exception ignored) { }
        }
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) { }
        }
    }

    // ---------- Gemini TTS ----------

    private byte[] geminiTts(String text) throws Exception {
        String key = prefs.getString("key", "");
        if (key.isEmpty()) return null;
        String voice = prefs.getString("voice", "Leda");
        String prompt = "Say this in a cute, bright, cheerful young anime girl voice, "
                + "soft, warm and playful, at a natural pace: " + text;

        JSONObject body = new JSONObject();
        body.put("contents", new JSONArray().put(new JSONObject()
                .put("parts", new JSONArray().put(new JSONObject().put("text", prompt)))));
        body.put("generationConfig", new JSONObject()
                .put("responseModalities", new JSONArray().put("AUDIO"))
                .put("speechConfig", new JSONObject()
                        .put("voiceConfig", new JSONObject()
                                .put("prebuiltVoiceConfig", new JSONObject().put("voiceName", voice)))));

        for (String model : TTS_MODELS) {
            String[] res;
            try {
                res = Brain.post(model, key, body, 30000);
            } catch (Exception e) {
                continue;
            }
            if (!"200".equals(res[0])) continue;
            JSONObject r = new JSONObject(res[1]);
            JSONArray cand = r.optJSONArray("candidates");
            if (cand == null || cand.length() == 0) continue;
            JSONObject content = cand.getJSONObject(0).optJSONObject("content");
            JSONArray parts = content != null ? content.optJSONArray("parts") : null;
            if (parts == null) continue;
            for (int i = 0; i < parts.length(); i++) {
                JSONObject inline = parts.getJSONObject(i).optJSONObject("inlineData");
                if (inline != null) {
                    String data = inline.optString("data", "");
                    if (!data.isEmpty()) return Base64.decode(data, Base64.DEFAULT);
                }
            }
        }
        return null;
    }

    private void play(byte[] pcm, int my) throws Exception {
        int frames = pcm.length / 2;
        AudioTrack at = new AudioTrack(
                new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build(),
                new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build(),
                pcm.length,
                AudioTrack.MODE_STATIC,
                AudioManager.AUDIO_SESSION_ID_GENERATE);
        track = at;
        try {
            at.write(pcm, 0, pcm.length);
            at.play();
            long end = System.currentTimeMillis() + (frames * 1000L / RATE) + 1500;
            while (my == token && at.getPlaybackHeadPosition() < frames
                    && System.currentTimeMillis() < end) {
                Thread.sleep(50);
            }
        } finally {
            try { at.stop(); } catch (Exception ignored) { }
            at.release();
            track = null;
        }
    }

    // ---------- Fallback: the phone's own voice ----------

    private void speakLocal(String text, int my, Runnable done) {
        if (my != token) return;
        if (tts == null || !ttsReady) {
            if (done != null) done.run();
            return;
        }
        Locale loc = BENGALI.matcher(text).find() ? new Locale("bn", "BD") : Locale.US;
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            Brain.log("সিস্টেম", "এই ভাষার ভয়েস ফোনে নেই। Settings এ Text-to-speech খুলে Google ভয়েস ইনস্টল করুন।");
            if (done != null) done.run();
            return;
        }
        tts.setPitch(1.35f);
        tts.setSpeechRate(1.05f);
        pendingDone = done;
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nexan");
    }
}
