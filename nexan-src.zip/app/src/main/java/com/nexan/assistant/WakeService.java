package com.nexan.assistant;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import ai.picovoice.porcupine.PorcupineManager;

import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.SpeechService;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Keeps listening in the background. When it hears "Hey Nexan" it beeps, listens for one
 * command, asks Gemini, speaks the answer and then goes back to waiting.
 */
public class WakeService extends Service {

    private static final String CHANNEL = "nexan_wake";
    private static final Pattern BENGALI = Pattern.compile("[\\u0980-\\u09FF]");
    private static final Pattern WAKE = Pattern.compile(
            "(?:(?:hey|hay|hi|hello|okay|ok|হে|হেই|হ্যালো|হেলো|ওহে)\\s*)?"
                    + "(?:nexan|nexon|nexen|nexin|nexun|neksan|next on|next one|"
                    + "নেক্সান|নেক্সন|নেক্সেন|নেক্সোন|নেক্সাম|নেকসান|নেক্সান)"
                    + "|(?:(?:hey|hay|হে|হেই)\\s*(?:jan|jaan|jon|জান))");

    private static volatile WakeService instance;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final Runnable cycle = this::startCycle;
    private final Runnable watchdog = this::afterTurn;

    private SpeechRecognizer rec;
    private Voice voice;
    private PowerManager.WakeLock wl;
    private boolean running = false;
    private boolean commandMode = false;
    private boolean paused = false;
    private boolean busy = false;
    private int errorStreak = 0;

    // Picovoice Porcupine ("Hey Nexan" wake word engine). Used only if an AccessKey and a .ppn file exist.
    private PorcupineManager pm;
    private boolean pmStarted = false;
    private boolean usePorcupine = false;

    // Vosk: free offline wake-word listening (used when Porcupine is not set up).
    private static final String VOSK_GRAMMAR =
            "[\"hey next on\", \"hey nexus\", \"hey nixon\", \"hey next one\", \"hey jan\", \"hey john\", \"hey jen\", \"[unk]\"]";
    private static final Pattern VOSK_WAKE = Pattern.compile(
            "hey\\s+(next\\s*on|nexus|nixon|next\\s+one|nex\\s*on|nexan|nexon|jan|john|jen)");
    private Model vModel;
    private Recognizer vRec;
    private SpeechService vService;
    private boolean useVosk = false;
    private boolean vStarted = false;
    private boolean loadingModel = false;

    // ---------- controls used by MainActivity ----------

    static void pause() {
        final WakeService s = instance;
        if (s != null) s.ui.post(() -> s.setPaused(true));
    }

    static void resume() {
        final WakeService s = instance;
        if (s != null) s.ui.post(() -> s.setPaused(false));
    }

    private void setPaused(boolean p) {
        paused = p;
        ui.removeCallbacks(cycle);
        if (p) {
            stopPm();
            stopVosk();
            if (rec != null) {
                try { rec.cancel(); } catch (Exception ignored) { }
            }
        } else {
            commandMode = false;
            next(300);
        }
    }

    // ---------- service lifecycle ----------

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Nexan listening", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("Nexan Ai")
                .setContentText("\"Hey Nexan\" বা \"Hey Jan\" বললে আমি শুনবো")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .setContentIntent(PendingIntent.getActivity(this, 0,
                        new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE))
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(1, n);
            }
        } catch (Exception e) {
            stopSelf();
            return;
        }
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "nexan:wake");
        wl.acquire();
        voice = new Voice(this);
        initPorcupine();
        initVosk();
        running = true;
        next(500);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        running = false;
        instance = null;
        ui.removeCallbacksAndMessages(null);
        destroyRec();
        stopPm();
        stopVosk();
        if (vModel != null) {
            try { vModel.close(); } catch (Throwable ignored) { }
            vModel = null;
        }
        if (pm != null) {
            try { pm.delete(); } catch (Exception ignored) { }
            pm = null;
        }
        if (voice != null) voice.shutdown();
        if (wl != null && wl.isHeld()) wl.release();
        super.onDestroy();
    }

    // ---------- Porcupine wake word ----------

    private String findPpn() {
        try {
            String[] names = getAssets().list("");
            if (names != null) {
                for (String n : names) {
                    if (n.endsWith(".ppn")) return n;
                }
            }
        } catch (Exception ignored) { }
        return null;
    }

    private void initPorcupine() {
        SharedPreferences prefs = getSharedPreferences("nexan", Context.MODE_PRIVATE);
        String key = prefs.getString("pv_key", "").trim();
        String ppn = findPpn();
        if (key.isEmpty() || ppn == null) return;
        try {
            pm = new PorcupineManager.Builder()
                    .setAccessKey(key)
                    .setKeywordPath(ppn)
                    .setSensitivity(0.7f)
                    .build(getApplicationContext(), keywordIndex -> ui.post(this::onWake));
            usePorcupine = true;
        } catch (Exception e) {
            pm = null;
            usePorcupine = false;
            Brain.log("ত্রুটি", "Porcupine চালু হয়নি, সাধারণ মোডে চলছে: " + e.getMessage());
        }
    }

    private void startPm() {
        if (pm == null) return;
        try {
            pm.start();
            pmStarted = true;
        } catch (Exception e) {
            usePorcupine = false;
            pmStarted = false;
            Brain.log("ত্রুটি", "Porcupine শুরু হয়নি, সাধারণ মোডে চলছে: " + e.getMessage());
        }
    }

    private void stopPm() {
        if (pm != null && pmStarted) {
            try { pm.stop(); } catch (Exception ignored) { }
        }
        pmStarted = false;
    }

    private void onWake() {
        if (!running || paused || busy || commandMode) return;
        stopPm();
        stopVosk();
        beep();
        commandMode = true;
        next(300);
    }

    // ---------- Vosk wake word ----------

    private void initVosk() {
        if (usePorcupine || !VoskModel.ready(this)) return;
        loadingModel = true;
        final String path = VoskModel.dir(this).getAbsolutePath();
        new Thread(() -> {
            Model m = null;
            String err = null;
            try {
                m = new Model(path);
            } catch (Throwable e) {
                err = String.valueOf(e.getMessage());
            }
            final Model fm = m;
            final String fe = err;
            ui.post(() -> {
                loadingModel = false;
                if (!running) {
                    if (fm != null) {
                        try { fm.close(); } catch (Throwable ignored) { }
                    }
                    return;
                }
                if (fm == null) {
                    Brain.log("ত্রুটি", "Vosk মডেল চালু হয়নি, সাধারণ মোডে চলছে: " + fe);
                    return;
                }
                vModel = fm;
                useVosk = true;
                next(100);
            });
        }).start();
    }

    private void startVosk() {
        if (vModel == null) {
            useVosk = false;
            return;
        }
        try {
            vRec = new Recognizer(vModel, 16000.0f, VOSK_GRAMMAR);
            vService = new SpeechService(vRec, 16000.0f);
            vService.startListening(voskListener);
            vStarted = true;
        } catch (Throwable e) {
            stopVosk();
            useVosk = false;
            Brain.log("ত্রুটি", "Vosk শুরু হয়নি, সাধারণ মোডে চলছে: " + e.getMessage());
        }
    }

    private void stopVosk() {
        vStarted = false;
        if (vService != null) {
            try { vService.cancel(); } catch (Throwable ignored) { }
            try { vService.shutdown(); } catch (Throwable ignored) { }
            vService = null;
        }
        if (vRec != null) {
            try { vRec.close(); } catch (Throwable ignored) { }
            vRec = null;
        }
    }

    private void checkVosk(String json, String field) {
        if (!vStarted || paused || busy || commandMode) return;
        try {
            String t = new JSONObject(json).optString(field, "");
            if (VOSK_WAKE.matcher(t).find()) onWake();
        } catch (Exception ignored) { }
    }

    private final org.vosk.android.RecognitionListener voskListener = new org.vosk.android.RecognitionListener() {
        @Override public void onPartialResult(String hypothesis) { checkVosk(hypothesis, "partial"); }
        @Override public void onResult(String hypothesis) { checkVosk(hypothesis, "text"); }
        @Override public void onFinalResult(String hypothesis) { checkVosk(hypothesis, "text"); }
        @Override public void onError(Exception exception) {
            if (!vStarted) return;
            stopVosk();
            next(2000);
        }
        @Override public void onTimeout() { }
    };

    // ---------- listening loop ----------

    private void next(long delayMs) {
        ui.removeCallbacks(cycle);
        ui.postDelayed(cycle, delayMs);
    }

    private void destroyRec() {
        if (rec != null) {
            try { rec.destroy(); } catch (Exception ignored) { }
            rec = null;
        }
    }

    private void startCycle() {
        if (!running) return;
        if (paused || busy) {
            next(700);
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf();
            return;
        }
        if (loadingModel) {
            next(500);
            return;
        }
        if (usePorcupine && !commandMode) {
            if (!pmStarted) startPm();
            if (usePorcupine) return;   // Porcupine is listening; its callback drives the next step
        }
        if (useVosk && !commandMode) {
            if (!vStarted) startVosk();
            if (useVosk) return;        // Vosk is listening; its callback drives the next step
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            next(5000);
            return;
        }
        if (rec == null) {
            rec = SpeechRecognizer.createSpeechRecognizer(this);
            rec.setRecognitionListener(listener);
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
        if (commandMode) {
            SharedPreferences prefs = getSharedPreferences("nexan", Context.MODE_PRIVATE);
            Brain.applyLang(i, prefs.getString("lang", "bn"));
        } else {
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
        }
        try {
            rec.startListening(i);
        } catch (Exception e) {
            destroyRec();
            next(1500);
        }
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override public void onReadyForSpeech(Bundle params) { }
        @Override public void onBeginningOfSpeech() { }
        @Override public void onRmsChanged(float rmsdB) { }
        @Override public void onBufferReceived(byte[] buffer) { }
        @Override public void onEndOfSpeech() { }
        @Override public void onPartialResults(Bundle partialResults) { }
        @Override public void onEvent(int eventType, Bundle params) { }

        @Override
        public void onError(int error) {
            if (paused || busy) return;
            if (commandMode) {
                commandMode = false;
                next(400);
                return;
            }
            if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                errorStreak = 0;
                next(250);
            } else if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) {
                destroyRec();
                next(1200);
            } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                stopSelf();
            } else {
                errorStreak++;
                if (errorStreak > 3) destroyRec();
                next(Math.min(1000L * errorStreak, 8000L));
            }
        }

        @Override
        public void onResults(Bundle results) {
            if (paused || busy) return;
            errorStreak = 0;
            ArrayList<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (commandMode) {
                commandMode = false;
                if (r != null && !r.isEmpty() && !r.get(0).trim().isEmpty()) {
                    handleCommand(r.get(0).trim());
                } else {
                    next(300);
                }
                return;
            }
            String cmd = detectWake(r);
            if (cmd == null) {
                next(150);
            } else if (cmd.length() >= 3) {
                handleCommand(cmd);
            } else {
                beep();
                commandMode = true;
                next(250);
            }
        }
    };

    /** Returns null if the wake phrase was not heard, "" if only the phrase was heard, else the command after it. */
    private static String detectWake(ArrayList<String> candidates) {
        if (candidates == null) return null;
        for (String c : candidates) {
            String n = c.toLowerCase(Locale.ROOT)
                    .replaceAll("[,.!?।:;\"']", " ")
                    .replaceAll("\\s+", " ")
                    .trim();
            Matcher m = WAKE.matcher(n);
            if (m.find()) {
                return n.substring(m.end()).trim();
            }
        }
        return null;
    }

    private void beep() {
        try {
            final ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_MUSIC, 70);
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 150);
            ui.postDelayed(tg::release, 500);
        } catch (Exception ignored) { }
    }

    // ---------- one conversation turn ----------

    private void handleCommand(final String text) {
        busy = true;
        ui.removeCallbacks(cycle);
        ui.removeCallbacks(watchdog);
        ui.postDelayed(watchdog, 60000);
        Brain.log("আপনি", text);
        new Thread(() -> {
            JSONObject out = null;
            String err = null;
            try {
                out = Brain.ask(getApplicationContext(), text);
            } catch (Exception e) {
                err = String.valueOf(e.getMessage());
            }
            final JSONObject fo = out;
            final String fe = err;
            ui.post(() -> {
                if (!running) return;
                if (fo == null) {
                    Brain.log("ত্রুটি", fe);
                    String sorry = BENGALI.matcher(text).find()
                            ? "দুঃখিত, একটা সমস্যা হয়েছে।" : "Sorry, something went wrong.";
                    voice.speak(sorry, this::afterTurn);
                    return;
                }
                String say = fo.optString("say", "");
                JSONArray acts = fo.optJSONArray("actions");
                if (acts != null) {
                    for (int k = 0; k < acts.length(); k++) {
                        final JSONObject a = acts.optJSONObject(k);
                        final long delay = 900L * (k + 1);
                        if (a != null) {
                            ui.postDelayed(() -> Actions.run(getApplicationContext(), a), delay);
                        }
                    }
                }
                if (!say.isEmpty()) {
                    Brain.log("Nexan", say);
                    voice.speak(say, this::afterTurn);
                } else {
                    afterTurn();
                }
            });
        }).start();
    }

    private void afterTurn() {
        ui.removeCallbacks(watchdog);
        busy = false;
        commandMode = false;
        next(400);
    }
}
