package com.nexan.assistant;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.provider.AlarmClock;

import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.Locale;

/** Phone actions. Works from an Activity or from a background Service. */
final class Actions {

    private Actions() { }

    private static void start(Context ctx, Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    private static void view(Context ctx, String url) {
        start(ctx, new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    static void run(Context ctx, JSONObject a) {
        String type = a.optString("type", "");
        try {
            switch (type) {
                case "open_app": {
                    String name = a.optString("name", "");
                    Intent li = findApp(ctx, name);
                    if (li != null) start(ctx, li);
                    else Brain.log("সিস্টেম", "\"" + name + "\" অ্যাপটা খুঁজে পেলাম না।");
                    break;
                }
                case "dial":
                    start(ctx, new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.optString("number", ""))));
                    break;
                case "alarm": {
                    Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                            .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                            .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", ""))
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    start(ctx, i);
                    break;
                }
                case "timer": {
                    Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                            .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    start(ctx, i);
                    break;
                }
                case "flashlight": {
                    CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
                    String[] ids = cm.getCameraIdList();
                    if (ids.length > 0) cm.setTorchMode(ids[0], a.optBoolean("on", true));
                    break;
                }
                case "web_search":
                    view(ctx, "https://www.google.com/search?q=" + URLEncoder.encode(a.optString("query", ""), "UTF-8"));
                    break;
                case "youtube":
                    view(ctx, "https://www.youtube.com/results?search_query=" + URLEncoder.encode(a.optString("query", ""), "UTF-8"));
                    break;
                case "maps":
                    view(ctx, "https://www.google.com/maps/search/?api=1&query=" + URLEncoder.encode(a.optString("query", ""), "UTF-8"));
                    break;
                case "open_url": {
                    String url = a.optString("url", "");
                    if (url.startsWith("https://") || url.startsWith("http://")) view(ctx, url);
                    break;
                }
                default:
                    break;
            }
        } catch (ActivityNotFoundException e) {
            Brain.log("সিস্টেম", "এই কাজের জন্য ফোনে উপযুক্ত অ্যাপ পাওয়া যায়নি।");
        } catch (Exception e) {
            Brain.log("সিস্টেম", "কাজটা করা গেল না: " + e.getMessage());
        }
    }

    private static Intent findApp(Context ctx, String query) {
        String q = query.toLowerCase(Locale.ROOT).trim();
        if (q.isEmpty()) return null;
        PackageManager pm = ctx.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        Intent best = null;
        int bestScore = 0;
        for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
            String label = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
            String pkg = ri.activityInfo.packageName;
            int score = 0;
            if (label.equals(q)) score = 100;
            else if (!label.isEmpty() && (label.contains(q) || q.contains(label))) score = 60;
            else if (pkg.toLowerCase(Locale.ROOT).contains(q.replace(" ", ""))) score = 40;
            if (score > bestScore) {
                Intent li = pm.getLaunchIntentForPackage(pkg);
                if (li != null) {
                    best = li;
                    bestScore = score;
                }
            }
        }
        return best;
    }
}
