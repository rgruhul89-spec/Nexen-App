package com.nexan.assistant;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** Brain (Gemini), voice (TextToSpeech) and phone actions. One shared instance for the app screen and the background service. */
public class Assistant {

    public interface Logger {
        void log(String who, String text);
    }

    public interface Result {
        void onResult(String say, JSONArray actions);

        void onError(String message);
    }

    private static final String SYSTEM = """
            You are Nexan Ai, a cheerful, warm and slightly playful personal voice assistant (like a friendly anime-style helper) living on the user's Android phone. The user wakes you by saying "Hey Nexan".
            The user speaks Bengali or English (sometimes mixed). Always reply in the language the user used; for Bengali always write Bengali script.
            Your replies are spoken aloud, so keep them short (one or two sentences), natural and kind. Do not use markdown, emojis or lists in "say".
            You can control the phone with actions. Reply with ONE JSON object only, in this shape:
            {"say": "text to speak", "actions": [ ... ]}
            Allowed actions:
            {"type":"open_app","name":"app name as shown on the phone, in English if possible"}
            {"type":"dial","number":"digits"}
            {"type":"alarm","hour":0-23,"minute":0-59,"label":""}
            {"type":"timer","seconds":number}
            {"type":"flashlight","on":true or false}
            {"type":"web_search","query":"..."}
            {"type":"youtube","query":"..."}
            {"type":"maps","query":"..."}
            {"type":"open_url","url":"https://..."}
            Use an empty actions array when no phone action is needed.
            Never claim to have done something you have no action for. If you cannot do it yet, say so honestly.
            """;

    private static final Pattern BENGALI = Pattern.compile("[\\u0980-\\u09FF]");
    private static Assistant instance;

    public static synchronized Assistant get(Context c) {
        if (instance == null) instance = new Assistant(c.getApplicationContext());
        return instance;
    }

    private final Context ctx;
    private final SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<String[]> history = new ArrayList<>();
    private final List<Runnable> waiting = new ArrayList<>();
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean ttsFailed = false;
    private volatile Logger logger;

    private Assistant(Context c) {
        ctx = c;
        prefs = c.getSharedPreferences("nexan", Context.MODE_PRIVATE);
        tts = new TextToSpeech(c, status -> ui.post(() -> {
            if (status == TextToSpeech.SUCCESS) ttsReady = true;
            else ttsFailed = true;
            List<Runnable> run = new ArrayList<>(waiting);
            waiting.clear();
            for (Runnable r : run) r.run();
        }));
    }

    public void setLogger(Logger l) {
        logger = l;
    }

    private void log(final String who, final String text) {
        final Logger l = logger;
        if (l != null) ui.post(() -> l.log(who, text));
    }

    public String lang() {
        return prefs.getString("lang", "bn");
    }

    public String apiKey() {
        return prefs.getString("key", "");
    }

    // ---------- Thinking ----------

    public void ask(final String text, final Result cb) {
        new Thread(() -> {
            try {
                final JSONObject out = askGemini(text);
                final String say = out.optString("say", "");
                final JSONArray acts = out.optJSONArray("actions");
                ui.post(() -> cb.onResult(say, acts == null ? new JSONArray() : acts));
            } catch (final Exception e) {
                log("ত্রুটি", String.valueOf(e.getMessage()));
                ui.post(() -> cb.onError(String.valueOf(e.getMessage())));
            }
        }).start();
    }

    private JSONObject turn(String role, String text) throws JSONException {
        return new JSONObject()
                .put("role", role)
                .put("parts", new JSONArray().put(new JSONObject().put("text", text)));
    }

    private JSONObject askGemini(String userText) throws Exception {
        String key = prefs.getString("key", "");
        if (key.isEmpty()) {
            throw new Exception("API key দেওয়া নেই। অ্যাপ খুলে ওপরের ⚙ চেপে Gemini key বসান।");
        }
        String time = new SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(new Date());
        JSONArray contents = new JSONArray();
        synchronized (history) {
            for (String[] m : history) contents.put(turn(m[0], m[1]));
        }
        contents.put(turn("user", userText));

        JSONObject body = new JSONObject();
        body.put("systemInstruction", new JSONObject().put("parts",
                new JSONArray().put(new JSONObject().put("text", SYSTEM + "\nCurrent local time: " + time))));
        body.put("contents", contents);
        body.put("generationConfig", new JSONObject()
                .put("temperature", 0.5)
                .put("maxOutputTokens", 700)
                .put("responseMimeType", "application/json"));

        String[] models = {"gemini-flash-lite-latest", "gemini-flash-latest"};
        String lastErr = "অজানা ত্রুটি";
        for (String model : models) {
            HttpURLConnection c = (HttpURLConnection) new URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent").openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(10000);
            c.setReadTimeout(25000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("x-goog-api-key", key);
            byte[] data = body.toString().getBytes("UTF-8");
            try (OutputStream os = c.getOutputStream()) {
                os.write(data);
            }
            int code = c.getResponseCode();
            String resp = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            c.disconnect();

            if (code == 200) {
                JSONObject r = new JSONObject(resp);
                JSONArray cand = r.optJSONArray("candidates");
                JSONObject content = (cand != null && cand.length() > 0)
                        ? cand.getJSONObject(0).optJSONObject("content") : null;
                JSONArray parts = content != null ? content.optJSONArray("parts") : null;
                if (parts == null) {
                    lastErr = "উত্তর আসেনি, আবার বলুন";
                    continue;
                }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < parts.length(); i++) {
                    sb.append(parts.getJSONObject(i).optString("text", ""));
                }
                String txt = sb.toString().trim();
                if (txt.startsWith("```")) {
                    txt = txt.replaceAll("^```[a-zA-Z]*\\s*", "").replaceAll("\\s*```$", "");
                }
                JSONObject out;
                try {
                    out = new JSONObject(txt);
                } catch (JSONException e) {
                    out = new JSONObject().put("say", txt).put("actions", new JSONArray());
                }
                synchronized (history) {
                    history.add(new String[]{"user", userText});
                    history.add(new String[]{"model", out.optString("say", "")});
                    while (history.size() > 12) history.remove(0);
                }
                return out;
            }
            lastErr = errorMessage(resp, code);
            if (code != 429 && code != 404 && code != 500 && code != 503) break;
        }
        throw new Exception(lastErr);
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        br.close();
        return sb.toString();
    }

    private String errorMessage(String resp, int code) {
        try {
            String m = new JSONObject(resp).getJSONObject("error").optString("message", "");
            if (!m.isEmpty()) return "Gemini ত্রুটি " + code + ": " + m;
        } catch (Exception ignored) {
        }
        if (code == 429) return "Gemini-র ফ্রি সীমা শেষ। কিছুক্ষণ পরে চেষ্টা করুন।";
        return "Gemini ত্রুটি " + code;
    }

    // ---------- Voice ----------

    /** Speaks the text, then calls done (on the main thread) when finished or if speaking is impossible. */
    public void speak(final String text, final Runnable done) {
        ui.post(() -> {
            if (ttsFailed) {
                log("সিস্টেম", "ভয়েস ইঞ্জিন চালু হয়নি।");
                if (done != null) done.run();
                return;
            }
            if (!ttsReady) {
                waiting.add(() -> speak(text, done));
                return;
            }
            boolean bn = BENGALI.matcher(text).find();
            int r = tts.setLanguage(bn ? new Locale("bn", "BD") : Locale.US);
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                log("সিস্টেম", "এই ভাষার ভয়েস ফোনে নেই। Settings এ Text-to-speech খুলে Google ভয়েস ইনস্টল করুন।");
                if (done != null) done.run();
                return;
            }
            String vn = prefs.getString(bn ? "voice_bn" : "voice_en", "");
            if (!vn.isEmpty()) {
                try {
                    Set<Voice> all = tts.getVoices();
                    if (all != null) {
                        for (Voice v : all) {
                            if (v.getName().equals(vn)) {
                                tts.setVoice(v);
                                break;
                            }
                        }
                    }
                } catch (Exception ignored) {
                }
            }
            tts.setPitch(prefs.getFloat("pitch", 1.3f));
            tts.setSpeechRate(prefs.getFloat("rate", 1.05f));
            final String id = "u" + System.nanoTime();
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override
                public void onStart(String utteranceId) {
                }

                @Override
                public void onDone(String utteranceId) {
                    if (done != null) ui.post(done);
                }

                @Override
                public void onError(String utteranceId) {
                    if (done != null) ui.post(done);
                }
            });
            int sr = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, id);
            if (sr != TextToSpeech.SUCCESS && done != null) done.run();
        });
    }

    public void stopSpeaking() {
        ui.post(() -> {
            if (tts != null && ttsReady) tts.stop();
        });
    }

    public List<Voice> voices(String langCode) {
        List<Voice> out = new ArrayList<>();
        if (!ttsReady) return out;
        try {
            Set<Voice> all = tts.getVoices();
            if (all != null) {
                for (Voice v : all) {
                    if (v.getLocale() != null && v.getLocale().getLanguage().equals(langCode)) out.add(v);
                }
            }
        } catch (Exception ignored) {
        }
        Collections.sort(out, (a, b) -> a.getName().compareTo(b.getName()));
        return out;
    }

    public void setVoice(String langCode, String name) {
        prefs.edit().putString("voice_" + langCode, name).apply();
    }

    public void setPitch(float p) {
        prefs.edit().putFloat("pitch", p).apply();
    }

    // ---------- Phone actions ----------

    public void runActions(JSONArray acts) {
        if (acts == null) return;
        for (int k = 0; k < acts.length(); k++) {
            final JSONObject a = acts.optJSONObject(k);
            final long delay = 900L * (k + 1);
            if (a != null) ui.postDelayed(() -> runAction(a), delay);
        }
    }

    private void start(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    private void view(String url) {
        start(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private void runAction(JSONObject a) {
        String type = a.optString("type", "");
        try {
            switch (type) {
                case "open_app": {
                    String name = a.optString("name", "");
                    Intent li = findApp(name);
                    if (li != null) start(li);
                    else log("সিস্টেম", "\"" + name + "\" অ্যাপটা খুঁজে পেলাম না।");
                    break;
                }
                case "dial":
                    start(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.optString("number", ""))));
                    break;
                case "alarm": {
                    Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                            .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                            .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", ""))
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    start(i);
                    break;
                }
                case "timer": {
                    Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                            .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    start(i);
                    break;
                }
                case "flashlight": {
                    CameraManager cm = (CameraManager) ctx.getSystemService(Context.CAMERA_SERVICE);
                    String[] ids = cm.getCameraIdList();
                    if (ids.length > 0) cm.setTorchMode(ids[0], a.optBoolean("on", true));
                    break;
                }
                case "web_search":
                    view("https://www.google.com/search?q=" + URLEncoder.encode(a.optString("query", ""), "UTF-8"));
                    break;
                case "youtube":
                    view("https://www.youtube.com/results?search_query=" + URLEncoder.encode(a.optString("query", ""), "UTF-8"));
                    break;
                case "maps":
                    view("https://www.google.com/maps/search/?api=1&query=" + URLEncoder.encode(a.optString("query", ""), "UTF-8"));
                    break;
                case "open_url": {
                    String url = a.optString("url", "");
                    if (url.startsWith("https://") || url.startsWith("http://")) view(url);
                    break;
                }
                default:
                    break;
            }
        } catch (ActivityNotFoundException e) {
            log("সিস্টেম", "এই কাজের জন্য ফোনে উপযুক্ত অ্যাপ পাওয়া যায়নি।");
        } catch (Exception e) {
            log("সিস্টেম", "কাজটা করা গেল না: " + e.getMessage());
        }
    }

    private Intent findApp(String query) {
        String q = query.toLowerCase(Locale.ROOT).trim();
        if (q.isEmpty()) return null;
        PackageManager pm = ctx.getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        Intent best = null;
        int bestScore = 0;
        for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
            String label = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
            String pkg = ri.activityInfo.packageName;
            int score = 0;
            if (label.equals(q)) score = 100;
            else if (!label.isEmpty() && (label.contains(q) || q.contains(label))) score = 60;
            else if (pkg.toLowerCase(Locale.ROOT).contains(q.replace(" ", ""))) score = 40;
            if (score > bestScore) {
                Intent li = pm.getLaunchIntentForPackage(pkg);
                if (li != null) {
                    best = li;
                    bestScore = score;
                }
            }
        }
        return best;
    }
}
