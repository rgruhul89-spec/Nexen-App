package com.nexan.assistant;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Downloads and unpacks the small offline English model used for "Hey Nexan" (Vosk). */
final class VoskModel {

    private static final String URL_ZIP = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip";

    interface Progress {
        void onProgress(int percent);
    }

    interface Done {
        /** error is null on success. */
        void onDone(String error);
    }

    private VoskModel() { }

    static File dir(Context c) {
        return new File(c.getFilesDir(), "vosk-model");
    }

    static boolean ready(Context c) {
        File d = dir(c);
        return new File(d, "conf").isDirectory() && new File(d, "am").isDirectory();
    }

    private static void deleteRec(File f) {
        if (f == null || !f.exists()) return;
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) deleteRec(k);
        }
        f.delete();
    }

    static void download(final Context ctx, final Progress p, final Done done) {
        final Context app = ctx.getApplicationContext();
        new Thread(() -> {
            String err = null;
            File zip = new File(app.getCacheDir(), "vosk-model.zip");
            File tmp = new File(app.getFilesDir(), "vosk-tmp");
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(URL_ZIP).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                int code = c.getResponseCode();
                if (code != 200) throw new Exception("HTTP " + code);
                long total = c.getContentLengthLong();
                try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(zip)) {
                    byte[] buf = new byte[65536];
                    long got = 0;
                    int n;
                    int last = -1;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        got += n;
                        if (total > 0) {
                            int pct = (int) (got * 90 / total);
                            if (pct != last) {
                                last = pct;
                                p.onProgress(pct);
                            }
                        }
                    }
                }
                c.disconnect();

                deleteRec(tmp);
                tmp.mkdirs();
                String tmpCanon = tmp.getCanonicalPath() + File.separator;
                try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))) {
                    ZipEntry e;
                    byte[] buf = new byte[65536];
                    while ((e = zin.getNextEntry()) != null) {
                        File f = new File(tmp, e.getName());
                        if (!f.getCanonicalPath().startsWith(tmpCanon)) throw new Exception("bad zip entry");
                        if (e.isDirectory()) {
                            f.mkdirs();
                            continue;
                        }
                        f.getParentFile().mkdirs();
                        try (FileOutputStream fo = new FileOutputStream(f)) {
                            int n;
                            while ((n = zin.read(buf)) > 0) fo.write(buf, 0, n);
                        }
                    }
                }
                p.onProgress(97);

                File[] kids = tmp.listFiles();
                File inner = (kids != null && kids.length == 1 && kids[0].isDirectory()) ? kids[0] : tmp;
                deleteRec(dir(app));
                if (!inner.renameTo(dir(app))) throw new Exception("মডেল সরানো যায়নি");
                deleteRec(tmp);
                zip.delete();
                if (!ready(app)) throw new Exception("মডেল ফাইল ঠিক নেই");
            } catch (Exception e) {
                err = String.valueOf(e.getMessage());
                zip.delete();
                deleteRec(tmp);
            }
            done.onDone(err);
        }).start();
    }
}
