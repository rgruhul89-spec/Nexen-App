package com.nexan.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Toast;

/** Invisible activity: starts a listening session right away, then closes itself. */
public class QuickActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "আগে অ্যাপ খুলে মাইকের অনুমতি দিন", Toast.LENGTH_LONG).show();
            Intent i = new Intent(this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
            return;
        }
        try {
            Intent s = new Intent(this, WakeService.class).setAction(WakeService.ACTION_LISTEN);
            startForegroundService(s);
        } catch (Exception e) {
            Toast.makeText(this, "শুরু করা গেল না: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        finish();
    }
}
