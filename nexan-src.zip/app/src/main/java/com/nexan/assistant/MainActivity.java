package com.nexan.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private TextView logView;
    private TextView statusView;
    private ScrollView scroll;
    private Button micBtn;
    private Button langBtn;
    private Button wakeBtn;
    private SpeechRecognizer recognizer;
    private Voice voice;
    private boolean listening = false;
    private boolean busy = false;
    private String lang = "bn";
    private final StringBuilder logText = new StringBuilder();
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("nexan", Context.MODE_PRIVATE);
        lang = prefs.getString("lang", "bn");
        buildUi();
        voice = new Voice(this);
        addLog("Nexan Ai", "আমি Nexan Ai। নিচের মাইক চেপে কথা বলুন, অথবা ওপরের “Hey Nexan” চালু করুন।");
        if (prefs.getString("key", "").isEmpty()) {
            showKeyDialog();
        }
        if (prefs.getBoolean("wake", false) && hasMic()) {
            startWake(false);
        }
        updateWakeBtn();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Brain.sink = (who, text) -> runOnUiThread(() -> addLog(who, text));
        updateWakeBtn();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Brain.sink = null;
    }

    // ---------- UI ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private String langLabel() {
        if (lang.equals("en")) return "English";
        if (lang.equals("auto")) return "বাংলা+EN";
        return "বাংলা";
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF05070D);
        root.setPadding(dp(16), dp(28), dp(16), dp(16));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Nexan Ai");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        top.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        langBtn = new Button(this);
        langBtn.setText(langLabel());
        langBtn.setOnClickListener(v -> toggleLang());
        top.addView(langBtn);

        Button voiceBtn = new Button(this);
        voiceBtn.setText("🎙");
        voiceBtn.setOnClickListener(v -> showVoiceDialog());
        top.addView(voiceBtn);

        Button gear = new Button(this);
        gear.setText("⚙");
        gear.setOnClickListener(v -> showSettingsMenu());
        top.addView(gear);

        root.addView(top);

        wakeBtn = new Button(this);
        wakeBtn.setTextColor(Color.WHITE);
        wakeBtn.setOnClickListener(v -> toggleWake());
        root.addView(wakeBtn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        scroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextColor(0xFFE6ECFF);
        logView.setTextSize(16);
        logView.setPadding(0, dp(12), 0, dp(12));
        scroll.addView(logView);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        statusView = new TextView(this);
        statusView.setTextColor(0xFF9CC0FF);
        statusView.setTextSize(14);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(0, dp(6), 0, dp(6));
        root.addView(statusView);

        micBtn = new Button(this);
        micBtn.setText("🎤  কথা বলুন");
        micBtn.setTextColor(Color.WHITE);
        micBtn.setTextSize(18);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF2F6BFF);
        bg.setCornerRadius(dp(40));
        micBtn.setBackground(bg);
        micBtn.setOnClickListener(v -> onMic());
        root.addView(micBtn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(72)));

        setContentView(root);
    }

    private void addLog(String who, String text) {
        logText.append(who).append(": ").append(text).append("\n\n");
        logView.setText(logText.toString());
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void status(String s) {
        statusView.setText(s);
    }

    private void toggleLang() {
        if (lang.equals("bn")) lang = "en";
        else if (lang.equals("en")) lang = "auto";
        else lang = "bn";
        prefs.edit().putString("lang", lang).apply();
        langBtn.setText(langLabel());
        if (lang.equals("bn")) status("এখন বাংলা শুনবো");
        else if (lang.equals("en")) status("Now listening in English");
        else status("বাংলা + English দুটোই শোনার চেষ্টা করবো");
    }

    private void showSettingsMenu() {
        new AlertDialog.Builder(this)
                .setTitle("সেটিংস")
                .setItems(new String[]{"Gemini API key", "Picovoice AccessKey (Hey Nexan)"}, (d, which) -> {
                    if (which == 0) showKeyDialog();
                    else showPicoDialog();
                })
                .show();
    }

    private void showKeyDialog() {
        final EditText et = new EditText(this);
        et.setHint("Gemini API key");
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        et.setText(prefs.getString("key", ""));
        new AlertDialog.Builder(this)
                .setTitle("Gemini API key")
                .setMessage("aistudio.google.com/apikey থেকে ফ্রি key নিয়ে এখানে বসান। key শুধু আপনার ফোনেই থাকবে।")
                .setView(et)
                .setPositiveButton("Save", (d, w) ->
                        prefs.edit().putString("key", et.getText().toString().trim()).apply())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private boolean hasPpn() {
        try {
            String[] names = getAssets().list("");
            if (names != null) {
                for (String n : names) {
                    if (n.endsWith(".ppn")) return true;
                }
            }
        } catch (Exception ignored) { }
        return false;
    }

    private void showPicoDialog() {
        final EditText et = new EditText(this);
        et.setHint("Picovoice AccessKey");
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        et.setText(prefs.getString("pv_key", ""));
        new AlertDialog.Builder(this)
                .setTitle("Picovoice AccessKey")
                .setMessage("console.picovoice.ai থেকে ফ্রি AccessKey নিয়ে এখানে বসান। এটা শুধু ফোনেই থাকবে।"
                        + (hasPpn() ? "" : "\n\n(এই অ্যাপে এখনো “Hey Nexan” এর .ppn ফাইল নেই, তাই সাধারণ মোডে চলবে।)"))
                .setView(et)
                .setPositiveButton("Save", (d, w) -> {
                    prefs.edit().putString("pv_key", et.getText().toString().trim()).apply();
                    if (prefs.getBoolean("wake", false)) {
                        stopService(new Intent(this, WakeService.class));
                        ui.postDelayed(() -> startWake(false), 600);
                    }
                    status("Picovoice key সেভ হয়েছে");
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void showVoiceDialog() {
        new AlertDialog.Builder(this)
                .setTitle("ভয়েস বাছুন (এখন: " + prefs.getString("voice", "Leda") + ")")
                .setItems(Voice.VOICES, (d, which) -> {
                    prefs.edit().putString("voice", Voice.VOICES[which]).apply();
                    status("ভয়েস: " + Voice.VOICES[which]);
                    voice.speak("হ্যালো, আমি নেক্সান। কেমন আছো?", null);
                })
                .show();
    }

    // ---------- "Hey Nexan" background listening ----------

    private boolean hasMic() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void updateWakeBtn() {
        boolean on = prefs.getBoolean("wake", false);
        wakeBtn.setText(on ? "👂 “Hey Nexan” চালু আছে (বন্ধ করতে চাপুন)" : "👂 “Hey Nexan” চালু করুন");
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(on ? 0xFF1E8E5A : 0xFF1B2440);
        bg.setCornerRadius(dp(20));
        wakeBtn.setBackground(bg);
    }

    private void toggleWake() {
        if (prefs.getBoolean("wake", false)) {
            prefs.edit().putBoolean("wake", false).apply();
            stopService(new Intent(this, WakeService.class));
            updateWakeBtn();
            status("“Hey Nexan” বন্ধ করা হয়েছে");
        } else {
            enableWake();
        }
    }

    private void enableWake() {
        if (!hasMic()) {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{
                        Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"}, 2);
            } else {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 2);
            }
            return;
        }
        ensureModelThenStart();
    }

    private boolean downloading = false;

    private void ensureModelThenStart() {
        boolean pico = !prefs.getString("pv_key", "").trim().isEmpty() && hasPpn();
        if (pico || VoskModel.ready(this)) {
            prefs.edit().putBoolean("wake", true).apply();
            startWake(true);
            updateWakeBtn();
            return;
        }
        if (downloading) return;
        downloading = true;
        status("ডাক শোনার মডেল নামছে (প্রায় ৪০ MB), নেট চালু রাখুন…");
        VoskModel.download(this,
                pct -> ui.post(() -> status("মডেল নামছে… " + pct + "%")),
                err -> ui.post(() -> {
                    downloading = false;
                    if (err == null) {
                        prefs.edit().putBoolean("wake", true).apply();
                        startWake(true);
                        updateWakeBtn();
                    } else {
                        status("মডেল নামানো যায়নি");
                        addLog("ত্রুটি", "মডেল নামানো যায়নি: " + err);
                    }
                }));
    }

    private void startWake(boolean userTap) {
        try {
            startForegroundService(new Intent(this, WakeService.class));
        } catch (Exception e) {
            addLog("ত্রুটি", "Hey Nexan চালু করা গেল না: " + e.getMessage());
            return;
        }
        if (userTap) {
            boolean pico = !prefs.getString("pv_key", "").trim().isEmpty() && hasPpn();
            String mode = pico ? "Picovoice মোড"
                    : (VoskModel.ready(this) ? "Vosk অফলাইন মোড" : "সাধারণ মোড");
            status("এখন “Hey Nexan” বলে ডাকুন (" + mode + ")");
            if (!Settings.canDrawOverlays(this)) showOverlayDialog();
        }
    }

    private void showOverlayDialog() {
        new AlertDialog.Builder(this)
                .setTitle("একটা অনুমতি দরকার")
                .setMessage("অ্যাপ বন্ধ থাকা অবস্থায় আমি যেন YouTube, অ্যালার্ম, ডায়ালার ইত্যাদি খুলতে পারি, "
                        + "তার জন্য “Display over other apps” অনুমতি দিন। (না দিলেও কথা বলা চলবে, শুধু অ্যাপ খোলার কাজগুলো ব্যাকগ্রাউন্ডে আটকে যেতে পারে।)")
                .setPositiveButton("অনুমতি দিন", (d, w) -> startActivity(new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))))
                .setNegativeButton("পরে", null)
                .show();
    }

    // ---------- Listening (mic button) ----------

    private void onMic() {
        if (listening) {
            if (recognizer != null) recognizer.stopListening();
            return;
        }
        if (!hasMic()) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            return;
        }
        startListening();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean micOk = hasMic();
        if (requestCode == 1) {
            if (micOk) startListening();
            else status("মাইকের অনুমতি লাগবে");
        } else if (requestCode == 2) {
            if (micOk) enableWake();
            else status("মাইকের অনুমতি লাগবে");
        }
    }

    private void startListening() {
        if (busy) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status("এই ফোনে Speech Recognition পাওয়া যাচ্ছে না (Google অ্যাপ লাগবে)");
            return;
        }
        WakeService.pause();
        voice.stop();
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {
                    listening = true;
                    micBtn.setText("⏹  শুনছি… (থামাতে চাপুন)");
                    status(lang.equals("en") ? "Listening…" : "শুনছি…");
                }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) {
                    listening = false;
                    micBtn.setText("🎤  কথা বলুন");
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        status("কিছু শুনতে পাইনি, আবার চেষ্টা করুন");
                    } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        status("মাইকের অনুমতি লাগবে");
                    } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) {
                        status("ইন্টারনেট সমস্যা (ভয়েস চেনার জন্য নেট লাগে)");
                    } else {
                        status("শোনার ত্রুটি, কোড " + error);
                    }
                    WakeService.resume();
                }
                @Override public void onResults(Bundle results) {
                    listening = false;
                    micBtn.setText("🎤  কথা বলুন");
                    ArrayList<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty() && !r.get(0).trim().isEmpty()) {
                        handleUserText(r.get(0).trim());
                    } else {
                        status("কিছু শুনতে পাইনি");
                        WakeService.resume();
                    }
                }
                @Override public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> r = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty()) status(r.get(0));
                }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        Brain.applyLang(i, lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizer.startListening(i);
    }

    // ---------- Thinking + speaking ----------

    private void handleUserText(final String text) {
        addLog("আপনি", text);
        status("ভাবছি…");
        busy = true;
        new Thread(() -> {
            try {
                final JSONObject out = Brain.ask(getApplicationContext(), text);
                runOnUiThread(() -> {
                    busy = false;
                    String say = out.optString("say", "");
                    JSONArray acts = out.optJSONArray("actions");
                    if (acts != null) {
                        for (int k = 0; k < acts.length(); k++) {
                            final JSONObject a = acts.optJSONObject(k);
                            final long delay = 900L * (k + 1);
                            if (a != null) ui.postDelayed(() -> Actions.run(getApplicationContext(), a), delay);
                        }
                    }
                    if (!say.isEmpty()) {
                        addLog("Nexan", say);
                        voice.speak(say, WakeService::resume);
                    } else {
                        WakeService.resume();
                    }
                    status("");
                });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    busy = false;
                    addLog("ত্রুটি", String.valueOf(e.getMessage()));
                    status("");
                    WakeService.resume();
                });
            }
        }).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (recognizer != null) recognizer.destroy();
        if (voice != null) voice.shutdown();
    }
}
