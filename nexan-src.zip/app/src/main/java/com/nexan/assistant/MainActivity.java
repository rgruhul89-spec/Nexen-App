package com.nexan.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.Voice;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private Assistant assistant;
    private TextView logView;
    private TextView statusView;
    private ScrollView scroll;
    private Button micBtn;
    private Button langBtn;
    private SpeechRecognizer recognizer;
    private boolean listening = false;
    private boolean busy = false;
    private String lang = "bn";
    private final StringBuilder logText = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("nexan", Context.MODE_PRIVATE);
        assistant = Assistant.get(this);
        lang = prefs.getString("lang", "bn");
        buildUi();
        assistant.setLogger(this::addLog);
        addLog("Nexan Ai", "আমি Nexan Ai। নিচের মাইক চেপে কথা বলুন।");
        if (prefs.getString("key", "").isEmpty()) {
            showKeyDialog();
        }
    }

    // ---------- UI ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF05070D);
        root.setPadding(dp(16), dp(28), dp(16), dp(16));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Nexan Ai");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        top.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        langBtn = new Button(this);
        langBtn.setText(lang.equals("bn") ? "বাংলা" : "English");
        langBtn.setOnClickListener(v -> toggleLang());
        top.addView(langBtn);

        Button voiceBtn = new Button(this);
        voiceBtn.setText("🔊");
        voiceBtn.setOnClickListener(v -> showVoiceMenu());
        top.addView(voiceBtn);

        Button gear = new Button(this);
        gear.setText("⚙");
        gear.setOnClickListener(v -> showKeyDialog());
        top.addView(gear);

        root.addView(top);

        scroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextColor(0xFFE6ECFF);
        logView.setTextSize(16);
        logView.setPadding(0, dp(12), 0, dp(12));
        scroll.addView(logView);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        statusView = new TextView(this);
        statusView.setTextColor(0xFF9CC0FF);
        statusView.setTextSize(14);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(0, dp(6), 0, dp(6));
        root.addView(statusView);

        micBtn = new Button(this);
        micBtn.setText("🎤  কথা বলুন");
        micBtn.setTextColor(Color.WHITE);
        micBtn.setTextSize(18);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF2F6BFF);
        bg.setCornerRadius(dp(40));
        micBtn.setBackground(bg);
        micBtn.setOnClickListener(v -> onMic());
        root.addView(micBtn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(72)));

        setContentView(root);
    }

    private void addLog(String who, String text) {
        logText.append(who).append(": ").append(text).append("\n\n");
        logView.setText(logText.toString());
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void status(String s) {
        statusView.setText(s);
    }

    private void toggleLang() {
        lang = lang.equals("bn") ? "en" : "bn";
        prefs.edit().putString("lang", lang).apply();
        langBtn.setText(lang.equals("bn") ? "বাংলা" : "English");
        status(lang.equals("bn") ? "এখন বাংলা শুনবো" : "Now listening in English");
    }

    private void showKeyDialog() {
        final EditText et = new EditText(this);
        et.setHint("Gemini API key");
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        et.setText(prefs.getString("key", ""));
        new AlertDialog.Builder(this)
                .setTitle("Gemini API key")
                .setMessage("aistudio.google.com/apikey থেকে ফ্রি key নিয়ে এখানে বসান। key শুধু আপনার ফোনেই থাকবে।")
                .setView(et)
                .setPositiveButton("Save", (d, w) ->
                        prefs.edit().putString("key", et.getText().toString().trim()).apply())
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------- Voice settings ----------

    private void showVoiceMenu() {
        final String[] items = {
                "বাংলা ভয়েস বেছে নিন",
                "English ভয়েস বেছে নিন",
                "পিচ: স্বাভাবিক",
                "পিচ: নরম মেয়েলি",
                "পিচ: অ্যানিমে স্টাইল"
        };
        new AlertDialog.Builder(this)
                .setTitle("ভয়েস")
                .setItems(items, (d, which) -> {
                    if (which == 0) pickVoice("bn");
                    else if (which == 1) pickVoice("en");
                    else if (which == 2) setPitchAndTest(1.0f);
                    else if (which == 3) setPitchAndTest(1.25f);
                    else setPitchAndTest(1.5f);
                })
                .show();
    }

    private void setPitchAndTest(float pitch) {
        assistant.setPitch(pitch);
        assistant.speak(lang.equals("bn") ? "আমি নেক্সান, আপনার সহকারী।" : "Hi, I am Nexan, your assistant.", null);
    }

    private void pickVoice(final String code) {
        final List<Voice> vs = assistant.voices(code);
        if (vs.isEmpty()) {
            addLog("সিস্টেম", "এই ভাষার ভয়েস পাওয়া যায়নি। ফোনের Settings এ Text-to-speech খুলে Google ভয়েস ইনস্টল করুন।");
            return;
        }
        String[] names = new String[vs.size()];
        for (int i = 0; i < vs.size(); i++) {
            names[i] = (i + 1) + ". " + vs.get(i).getName();
        }
        new AlertDialog.Builder(this)
                .setTitle("ভয়েস বেছে নিন (চাপলেই শুনতে পাবেন)")
                .setItems(names, (d, w) -> {
                    assistant.setVoice(code, vs.get(w).getName());
                    assistant.speak(code.equals("bn") ? "আমি নেক্সান, আপনার সহকারী।" : "Hi, I am Nexan, your assistant.", null);
                })
                .show();
    }

    // ---------- Listening ----------

    private void onMic() {
        if (listening) {
            if (recognizer != null) recognizer.stopListening();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            return;
        }
        startListening();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else {
            status("মাইকের অনুমতি লাগবে");
        }
    }

    private void startListening() {
        if (busy) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status("এই ফোনে Speech Recognition পাওয়া যাচ্ছে না (Google অ্যাপ লাগবে)");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {
                    listening = true;
                    micBtn.setText("⏹  শুনছি… (থামাতে চাপুন)");
                    status(lang.equals("bn") ? "শুনছি…" : "Listening…");
                }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) {
                    listening = false;
                    micBtn.setText("🎤  কথা বলুন");
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        status("কিছু শুনতে পাইনি, আবার চেষ্টা করুন");
                    } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        status("মাইকের অনুমতি লাগবে");
                    } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) {
                        status("ইন্টারনেট সমস্যা (ভয়েস চেনার জন্য নেট লাগে)");
                    } else {
                        status("শোনার ত্রুটি, কোড " + error);
                    }
                }
                @Override public void onResults(Bundle results) {
                    listening = false;
                    micBtn.setText("🎤  কথা বলুন");
                    ArrayList<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty() && !r.get(0).trim().isEmpty()) {
                        handleUserText(r.get(0).trim());
                    } else {
                        status("কিছু শুনতে পাইনি");
                    }
                }
                @Override public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> r = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty()) status(r.get(0));
                }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
        }
        assistant.stopSpeaking();
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.equals("bn") ? "bn-BD" : "en-US");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizer.startListening(i);
    }

    // ---------- Thinking ----------

    private void handleUserText(final String text) {
        addLog("আপনি", text);
        status("ভাবছি…");
        busy = true;
        assistant.ask(text, new Assistant.Result() {
            @Override
            public void onResult(String say, JSONArray actions) {
                busy = false;
                status("");
                if (!say.isEmpty()) {
                    addLog("Nexan", say);
                    assistant.speak(say, null);
                }
                assistant.runActions(actions);
            }

            @Override
            public void onError(String message) {
                busy = false;
                status("");
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        assistant.setLogger(null);
        if (recognizer != null) recognizer.destroy();
    }
}
