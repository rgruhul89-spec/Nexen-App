package com.nexan.assistant;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.AlarmClock;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String SYSTEM = """
            You are Nexan Ai, a friendly personal voice assistant living on the user's Android phone.
            The user speaks Bengali or English (sometimes mixed). Always reply in the language the user used; for Bengali always write Bengali script.
            Keep spoken replies short (one or two sentences), natural and warm. Do not use markdown, emojis or lists in "say".
            You can control the phone with actions. Reply with ONE JSON object only, in this shape:
            {"say": "text to speak", "actions": [ ... ]}
            Allowed actions:
            {"type":"open_app","name":"app name as shown on the phone, in English if possible"}
            {"type":"dial","number":"digits"}
            {"type":"alarm","hour":0-23,"minute":0-59,"label":""}
            {"type":"timer","seconds":number}
            {"type":"flashlight","on":true or false}
            {"type":"web_search","query":"..."}
            {"type":"youtube","query":"..."}
            {"type":"maps","query":"..."}
            {"type":"open_url","url":"https://..."}
            Use an empty actions array when no phone action is needed.
            Never claim to have done something you have no action for. If you cannot do it yet, say so honestly.
            """;

    private static final Pattern BENGALI = Pattern.compile("[\\u0980-\\u09FF]");

    private SharedPreferences prefs;
    private TextView logView;
    private TextView statusView;
    private ScrollView scroll;
    private Button micBtn;
    private Button langBtn;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean listening = false;
    private boolean busy = false;
    private String lang = "bn";
    private final StringBuilder logText = new StringBuilder();
    private final List<String[]> history = new ArrayList<>();
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("nexan", Context.MODE_PRIVATE);
        lang = prefs.getString("lang", "bn");
        buildUi();
        tts = new TextToSpeech(this, status -> { });
        addLog("Nexan Ai", "আমি Nexan Ai। নিচের মাইক চেপে কথা বলুন।");
        if (prefs.getString("key", "").isEmpty()) {
            showKeyDialog();
        }
    }

    // ---------- UI ----------

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF05070D);
        root.setPadding(dp(16), dp(28), dp(16), dp(16));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("Nexan Ai");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        top.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        langBtn = new Button(this);
        langBtn.setText(lang.equals("bn") ? "বাংলা" : "English");
        langBtn.setOnClickListener(v -> toggleLang());
        top.addView(langBtn);

        Button gear = new Button(this);
        gear.setText("⚙");
        gear.setOnClickListener(v -> showKeyDialog());
        top.addView(gear);

        root.addView(top);

        scroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextColor(0xFFE6ECFF);
        logView.setTextSize(16);
        logView.setPadding(0, dp(12), 0, dp(12));
        scroll.addView(logView);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        statusView = new TextView(this);
        statusView.setTextColor(0xFF9CC0FF);
        statusView.setTextSize(14);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(0, dp(6), 0, dp(6));
        root.addView(statusView);

        micBtn = new Button(this);
        micBtn.setText("🎤  কথা বলুন");
        micBtn.setTextColor(Color.WHITE);
        micBtn.setTextSize(18);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF2F6BFF);
        bg.setCornerRadius(dp(40));
        micBtn.setBackground(bg);
        micBtn.setOnClickListener(v -> onMic());
        root.addView(micBtn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(72)));

        setContentView(root);
    }

    private void addLog(String who, String text) {
        logText.append(who).append(": ").append(text).append("\n\n");
        logView.setText(logText.toString());
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void status(String s) {
        statusView.setText(s);
    }

    private void toggleLang() {
        lang = lang.equals("bn") ? "en" : "bn";
        prefs.edit().putString("lang", lang).apply();
        langBtn.setText(lang.equals("bn") ? "বাংলা" : "English");
        status(lang.equals("bn") ? "এখন বাংলা শুনবো" : "Now listening in English");
    }

    private void showKeyDialog() {
        final EditText et = new EditText(this);
        et.setHint("Gemini API key");
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        et.setText(prefs.getString("key", ""));
        new AlertDialog.Builder(this)
                .setTitle("Gemini API key")
                .setMessage("aistudio.google.com/apikey থেকে ফ্রি key নিয়ে এখানে বসান। key শুধু আপনার ফোনেই থাকবে।")
                .setView(et)
                .setPositiveButton("Save", (d, w) ->
                        prefs.edit().putString("key", et.getText().toString().trim()).apply())
                .setNegativeButton("Cancel", null)
                .show();
    }

    // ---------- Listening ----------

    private void onMic() {
        if (listening) {
            if (recognizer != null) recognizer.stopListening();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            return;
        }
        startListening();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening();
        } else {
            status("মাইকের অনুমতি লাগবে");
        }
    }

    private void startListening() {
        if (busy) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status("এই ফোনে Speech Recognition পাওয়া যাচ্ছে না (Google অ্যাপ লাগবে)");
            return;
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {
                    listening = true;
                    micBtn.setText("⏹  শুনছি… (থামাতে চাপুন)");
                    status(lang.equals("bn") ? "শুনছি…" : "Listening…");
                }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) {
                    listening = false;
                    micBtn.setText("🎤  কথা বলুন");
                    if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                        status("কিছু শুনতে পাইনি, আবার চেষ্টা করুন");
                    } else if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        status("মাইকের অনুমতি লাগবে");
                    } else if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT) {
                        status("ইন্টারনেট সমস্যা (ভয়েস চেনার জন্য নেট লাগে)");
                    } else {
                        status("শোনার ত্রুটি, কোড " + error);
                    }
                }
                @Override public void onResults(Bundle results) {
                    listening = false;
                    micBtn.setText("🎤  কথা বলুন");
                    ArrayList<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty() && !r.get(0).trim().isEmpty()) {
                        handleUserText(r.get(0).trim());
                    } else {
                        status("কিছু শুনতে পাইনি");
                    }
                }
                @Override public void onPartialResults(Bundle partialResults) {
                    ArrayList<String> r = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (r != null && !r.isEmpty()) status(r.get(0));
                }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
        }
        if (tts != null) tts.stop();
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang.equals("bn") ? "bn-BD" : "en-US");
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        recognizer.startListening(i);
    }

    // ---------- Thinking (Gemini) ----------

    private void handleUserText(final String text) {
        addLog("আপনি", text);
        status("ভাবছি…");
        busy = true;
        new Thread(() -> {
            try {
                final JSONObject out = askGemini(text);
                runOnUiThread(() -> {
                    busy = false;
                    String say = out.optString("say", "");
                    if (!say.isEmpty()) {
                        addLog("Nexan", say);
                        speak(say);
                    }
                    JSONArray acts = out.optJSONArray("actions");
                    if (acts != null) {
                        for (int k = 0; k < acts.length(); k++) {
                            final JSONObject a = acts.optJSONObject(k);
                            final long delay = 900L * (k + 1);
                            if (a != null) ui.postDelayed(() -> runAction(a), delay);
                        }
                    }
                    status("");
                });
            } catch (final Exception e) {
                runOnUiThread(() -> {
                    busy = false;
                    addLog("ত্রুটি", String.valueOf(e.getMessage()));
                    status("");
                });
            }
        }).start();
    }

    private JSONObject turn(String role, String text) throws JSONException {
        return new JSONObject()
                .put("role", role)
                .put("parts", new JSONArray().put(new JSONObject().put("text", text)));
    }

    private JSONObject askGemini(String userText) throws Exception {
        String key = prefs.getString("key", "");
        if (key.isEmpty()) {
            throw new Exception("API key দেওয়া নেই। ওপরের ⚙ চেপে Gemini key বসান।");
        }
        String time = new SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(new Date());
        JSONArray contents = new JSONArray();
        for (String[] m : history) contents.put(turn(m[0], m[1]));
        contents.put(turn("user", userText));

        JSONObject body = new JSONObject();
        body.put("systemInstruction", new JSONObject().put("parts",
                new JSONArray().put(new JSONObject().put("text", SYSTEM + "\nCurrent local time: " + time))));
        body.put("contents", contents);
        body.put("generationConfig", new JSONObject()
                .put("temperature", 0.4)
                .put("maxOutputTokens", 700)
                .put("responseMimeType", "application/json"));

        String[] models = {"gemini-flash-lite-latest", "gemini-flash-latest"};
        String lastErr = "অজানা ত্রুটি";
        for (String model : models) {
            HttpURLConnection c = (HttpURLConnection) new URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent").openConnection();
            c.setRequestMethod("POST");
            c.setConnectTimeout(10000);
            c.setReadTimeout(25000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("x-goog-api-key", key);
            byte[] data = body.toString().getBytes("UTF-8");
            try (OutputStream os = c.getOutputStream()) {
                os.write(data);
            }
            int code = c.getResponseCode();
            String resp = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
            c.disconnect();

            if (code == 200) {
                JSONObject r = new JSONObject(resp);
                JSONArray cand = r.optJSONArray("candidates");
                JSONObject content = (cand != null && cand.length() > 0)
                        ? cand.getJSONObject(0).optJSONObject("content") : null;
                JSONArray parts = content != null ? content.optJSONArray("parts") : null;
                if (parts == null) {
                    lastErr = "উত্তর আসেনি, আবার বলুন";
                    continue;
                }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < parts.length(); i++) {
                    sb.append(parts.getJSONObject(i).optString("text", ""));
                }
                String txt = sb.toString().trim();
                if (txt.startsWith("```")) {
                    txt = txt.replaceAll("^```[a-zA-Z]*\\s*", "").replaceAll("\\s*```$", "");
                }
                JSONObject out;
                try {
                    out = new JSONObject(txt);
                } catch (JSONException e) {
                    out = new JSONObject().put("say", txt).put("actions", new JSONArray());
                }
                history.add(new String[]{"user", userText});
                history.add(new String[]{"model", out.optString("say", "")});
                while (history.size() > 12) history.remove(0);
                return out;
            }
            lastErr = errorMessage(resp, code);
            if (code != 429 && code != 404 && code != 500 && code != 503) break;
        }
        throw new Exception(lastErr);
    }

    private String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        br.close();
        return sb.toString();
    }

    private String errorMessage(String resp, int code) {
        try {
            String m = new JSONObject(resp).getJSONObject("error").optString("message", "");
            if (!m.isEmpty()) return "Gemini ত্রুটি " + code + ": " + m;
        } catch (Exception ignored) { }
        if (code == 429) return "Gemini-র ফ্রি সীমা শেষ। কিছুক্ষণ পরে চেষ্টা করুন।";
        return "Gemini ত্রুটি " + code;
    }

    // ---------- Speaking ----------

    private void speak(String text) {
        if (tts == null) return;
        Locale loc = BENGALI.matcher(text).find() ? new Locale("bn", "BD") : Locale.US;
        int r = tts.setLanguage(loc);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            addLog("সিস্টেম", "এই ভাষার ভয়েস ফোনে নেই। Settings এ Text-to-speech খুলে Google ভয়েস ইনস্টল করুন।");
            return;
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nexan");
    }

    // ---------- Phone actions ----------

    private void runAction(JSONObject a) {
        String type = a.optString("type", "");
        try {
            switch (type) {
                case "open_app": {
                    String name = a.optString("name", "");
                    Intent li = findApp(name);
                    if (li != null) startActivity(li);
                    else addLog("সিস্টেম", "\"" + name + "\" অ্যাপটা খুঁজে পেলাম না।");
                    break;
                }
                case "dial":
                    startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + a.optString("number", ""))));
                    break;
                case "alarm": {
                    Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                            .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                            .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", ""))
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    startActivity(i);
                    break;
                }
                case "timer": {
                    Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                            .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                            .putExtra(AlarmClock.EXTRA_SKIP_UI, true);
                    startActivity(i);
                    break;
                }
                case "flashlight": {
                    CameraManager cm = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
                    String[] ids = cm.getCameraIdList();
                    if (ids.length > 0) cm.setTorchMode(ids[0], a.optBoolean("on", true));
                    break;
                }
                case "web_search":
                    view("https://www.google.com/search?q=" + URLEncoder.encode(a.optString("query", ""), "UTF-8"));
                    break;
                case "youtube":
                    view("https://www.youtube.com/results?search_query=" + URLEncoder.encode(a.optString("query", ""), "UTF-8"));
                    break;
                case "maps":
                    view("https://www.google.com/maps/search/?api=1&query=" + URLEncoder.encode(a.optString("query", ""), "UTF-8"));
                    break;
                case "open_url": {
                    String url = a.optString("url", "");
                    if (url.startsWith("https://") || url.startsWith("http://")) view(url);
                    break;
                }
                default:
                    break;
            }
        } catch (ActivityNotFoundException e) {
            addLog("সিস্টেম", "এই কাজের জন্য ফোনে উপযুক্ত অ্যাপ পাওয়া যায়নি।");
        } catch (Exception e) {
            addLog("সিস্টেম", "কাজটা করা গেল না: " + e.getMessage());
        }
    }

    private void view(String url) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private Intent findApp(String query) {
        String q = query.toLowerCase(Locale.ROOT).trim();
        if (q.isEmpty()) return null;
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        Intent best = null;
        int bestScore = 0;
        for (ResolveInfo ri : pm.queryIntentActivities(main, 0)) {
            String label = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
            String pkg = ri.activityInfo.packageName;
            int score = 0;
            if (label.equals(q)) score = 100;
            else if (!label.isEmpty() && (label.contains(q) || q.contains(label))) score = 60;
            else if (pkg.toLowerCase(Locale.ROOT).contains(q.replace(" ", ""))) score = 40;
            if (score > bestScore) {
                Intent li = pm.getLaunchIntentForPackage(pkg);
                if (li != null) {
                    best = li;
                    bestScore = score;
                }
            }
        }
        return best;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
    }
}
