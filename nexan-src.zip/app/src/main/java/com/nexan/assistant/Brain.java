package com.nexan.assistant;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.speech.RecognizerIntent;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Shared "brain": talks to Gemini. Used by the screen and by the background wake service. */
final class Brain {

    interface Sink {
        void log(String who, String text);
    }

    /** Set by MainActivity while it is on screen, so background conversations show up in the log. */
    static volatile Sink sink;

    static void log(String who, String text) {
        Sink s = sink;
        if (s != null) s.log(who, text);
    }

    static final String SYSTEM = """
            You are Nexan Ai, a friendly personal voice assistant living on the user's Android phone.
            Your personality: a cheerful, kind, slightly playful anime-style girl. Warm and cute, but never childish or annoying.
            The user speaks Bengali or English (sometimes mixed). Always reply in the language the user used; for Bengali always write Bengali script.
            Your "say" text is read aloud by a voice, so keep it short (one or two sentences), natural and warm. Do not use markdown, emojis, asterisks or lists in "say".
            You can control the phone with actions. Reply with ONE JSON object only, in this shape:
            {"say": "text to speak", "actions": [ ... ]}
            Allowed actions:
            {"type":"open_app","name":"app name as shown on the phone, in English if possible"}
            {"type":"dial","number":"digits"}
            {"type":"alarm","hour":0-23,"minute":0-59,"label":""}
            {"type":"timer","seconds":number}
            {"type":"flashlight","on":true or false}
            {"type":"web_search","query":"..."}
            {"type":"youtube","query":"..."}
            {"type":"maps","query":"..."}
            {"type":"open_url","url":"https://..."}
            Use an empty actions array when no phone action is needed.
            Never claim to have done something you have no action for. If you cannot do it yet, say so honestly.
            """;

    private static final List<String[]> history = new ArrayList<>();

    private Brain() { }

    /** lang is "bn", "en" or "auto" (Bengali first, English as an additional language). */
    static void applyLang(Intent i, String lang) {
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en".equals(lang) ? "en-US" : "bn-BD");
        if ("auto".equals(lang)) {
            i.putExtra("android.speech.extra.ADDITIONAL_LANGUAGES", new String[]{"en-US"});
        }
    }

    static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        BufferedReader br = new BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append('\n');
        br.close();
        return sb.toString();
    }

    /** POSTs a generateContent request. Returns {httpCode, responseBody}. */
    static String[] post(String model, String key, JSONObject body, int readMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(
                "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent").openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(10000);
        c.setReadTimeout(readMs);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("x-goog-api-key", key);
        byte[] data = body.toString().getBytes("UTF-8");
        try (OutputStream os = c.getOutputStream()) {
            os.write(data);
        }
        int code = c.getResponseCode();
        String resp = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
        c.disconnect();
        return new String[]{String.valueOf(code), resp};
    }

    private static JSONObject turn(String role, String text) throws JSONException {
        return new JSONObject()
                .put("role", role)
                .put("parts", new JSONArray().put(new JSONObject().put("text", text)));
    }

    static String errorMessage(String resp, int code) {
        try {
            String m = new JSONObject(resp).getJSONObject("error").optString("message", "");
            if (!m.isEmpty()) return "Gemini ত্রুটি " + code + ": " + m;
        } catch (Exception ignored) { }
        if (code == 429) return "Gemini-র ফ্রি সীমা শেষ। কিছুক্ষণ পরে চেষ্টা করুন।";
        return "Gemini ত্রুটি " + code;
    }

    static JSONObject ask(Context ctx, String userText) throws Exception {
        SharedPreferences prefs = ctx.getSharedPreferences("nexan", Context.MODE_PRIVATE);
        String key = prefs.getString("key", "");
        if (key.isEmpty()) {
            throw new Exception("API key দেওয়া নেই। অ্যাপ খুলে ওপরের ⚙ চেপে Gemini key বসান।");
        }
        String time = new SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(new Date());
        JSONArray contents = new JSONArray();
        synchronized (history) {
            for (String[] m : history) contents.put(turn(m[0], m[1]));
        }
        contents.put(turn("user", userText));

        JSONObject body = new JSONObject();
        body.put("systemInstruction", new JSONObject().put("parts",
                new JSONArray().put(new JSONObject().put("text", SYSTEM + "\nCurrent local time: " + time))));
        body.put("contents", contents);
        body.put("generationConfig", new JSONObject()
                .put("temperature", 0.5)
                .put("maxOutputTokens", 700)
                .put("responseMimeType", "application/json"));

        String[] models = {"gemini-flash-lite-latest", "gemini-flash-latest"};
        String lastErr = "অজানা ত্রুটি";
        for (String model : models) {
            String[] res = post(model, key, body, 25000);
            int code = Integer.parseInt(res[0]);
            String resp = res[1];

            if (code == 200) {
                JSONObject r = new JSONObject(resp);
                JSONArray cand = r.optJSONArray("candidates");
                JSONObject content = (cand != null && cand.length() > 0)
                        ? cand.getJSONObject(0).optJSONObject("content") : null;
                JSONArray parts = content != null ? content.optJSONArray("parts") : null;
                if (parts == null) {
                    lastErr = "উত্তর আসেনি, আবার বলুন";
                    continue;
                }
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < parts.length(); i++) {
                    sb.append(parts.getJSONObject(i).optString("text", ""));
                }
                String txt = sb.toString().trim();
                if (txt.startsWith("```")) {
                    txt = txt.replaceAll("^```[a-zA-Z]*\\s*", "").replaceAll("\\s*```$", "");
                }
                JSONObject out;
                try {
                    out = new JSONObject(txt);
                } catch (JSONException e) {
                    out = new JSONObject().put("say", txt).put("actions", new JSONArray());
                }
                synchronized (history) {
                    history.add(new String[]{"user", userText});
                    history.add(new String[]{"model", out.optString("say", "")});
                    while (history.size() > 12) history.remove(0);
                }
                return out;
            }
            lastErr = errorMessage(resp, code);
            if (code != 429 && code != 404 && code != 500 && code != 503) break;
        }
        throw new Exception(lastErr);
    }
}
