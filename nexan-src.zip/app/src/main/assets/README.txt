Put the Picovoice .ppn wake word file (trained for Android) in this folder.
